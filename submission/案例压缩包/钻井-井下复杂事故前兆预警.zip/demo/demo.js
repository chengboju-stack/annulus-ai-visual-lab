/* final-lab-interactions:start */
(function(){
  'use strict';
  var configs={
    c1:{metrics:[['selected-class','候选类别'],['selected-confidence','相似度置信分'],['review-share','复核比例']],presets:[['良好响应','低振幅与较弱套管波特征',{depth:24,confidence:72}],['过渡区间','检查靠近分类边界的位置',{depth:72,confidence:92}],['较差响应','比较较强套管波特征',{depth:112,confidence:72}]]},
    c2:{metrics:[['current-efficiency','当前预测效率'],['best-efficiency','候选最高效率'],['frac-margin','破裂压力余量']],presets:[['保守方案','较低排量与适中密度',{density:1400,rate:8,centralization:70}],['高排量试探','检查效率改善是否触及压力约束',{density:1640,rate:20,centralization:70}],['改善居中度','固定密度排量，只改变几何条件',{density:1500,rate:13,centralization:95}]]},
    c3:{metrics:[['risk-probability','模型风险分数'],['risk-level','当前风险提示'],['recall-score','留出样本召回率']],presets:[['宽窗口','余量充足，邻井历史频率低',{'window-width':75,'ecd-margin':24,'history-rate':0,'decision-threshold':45}],['窄窗口','多因素叠加，观察贡献变化',{'window-width':25,'ecd-margin':3,'history-rate':45,'decision-threshold':45}],['提高阈值','固定井况，区分分数与决策',{'window-width':42,'ecd-margin':10,'history-rate':18,'decision-threshold':70}]]},
    c4:{metrics:[['min-after','方案最小居中度'],['coverage-after','目标覆盖率'],['used-count','扶正器数量']],presets:[['无扶正器','建立原始几何对照',{eccentricity:55,target:65,'max-centralizers':0,depth:120}],['布置五个','在数量约束下搜索薄弱段',{eccentricity:55,target:65,'max-centralizers':5,depth:120}],['增加上限','观察新增位置是否仍有收益',{eccentricity:55,target:65,'max-centralizers':8,depth:120}]]},
    d2:{metrics:[['anomaly-score','异常分数'],['persistence','超限持续窗'],['top-channel','贡献最大通道']],presets:[['正常留出窗','正常工况下也应检查误报',{scenario:'normal','time-index':100,threshold:62}],['井漏前兆','让多个通道共同参与判断',{scenario:'loss','time-index':100,threshold:62}],['降低阈值','相同早期时刻，调整决策灵敏度',{scenario:'loss','time-index':80,threshold:35}]]}
  };
  var scene=document.querySelector('main').dataset.scene,config=configs[scene];if(!config)return;
  var root=document.getElementById('lab-interactions');if(!root)return;
  root.innerHTML='<div class="guided-top"><div><span>EXPERIMENT / 自己动手验证</span><h2>先选工况，再保存一组对照。</h2></div><span class="guided-index">'+(scene==='d2'?'拓展实验':'固井实验')+'</span></div><div class="guided-presets">'+config.presets.map(function(p,i){return '<button type="button" data-lab-preset="'+i+'" aria-pressed="false"><b>0'+(i+1)+'</b><span>'+p[0]+'<small>'+p[1]+'</small></span><i>↗</i></button>';}).join('')+'</div><div class="comparison-tools"><p id="guided-instruction">点击一种典型工况；保存为 A 后，调整下方参数查看 A / B 对比。</p><button type="button" id="save-lab-baseline">保存当前为方案 A</button><button type="button" id="clear-lab-baseline" hidden>清除对照</button></div><div id="lab-comparison" hidden aria-live="polite"></div>';
  var saved=null;
  function measure(){return config.metrics.map(function(m){var node=document.getElementById(m[0]);return {label:m[1],text:node?node.textContent.trim():'—'};});}
  function safe(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function conditionText(inputs){var names={confidence:'最低置信 %',depth:'测深 m',density:'密度 kg/m³',rate:'排量 L/s',centralization:'居中度 %','window-width':'窗口宽度 ×0.01 g/cm³','ecd-margin':'ECD 余量 ×0.01 g/cm³','history-rate':'历史频率 %','decision-threshold':'预警阈值 %',eccentricity:'偏心 %',target:'目标 %','max-centralizers':'数量上限',threshold:'阈值 %','time-index':'时间窗索引'};return inputs.map(function(x){return (names[x.id]||x.id)+' '+x.value;}).join(' · ');}
  function compare(){if(!saved)return;var now=measure(),out=document.getElementById('lab-comparison');out.hidden=false;out.innerHTML='<div class="compare-intro"><span>方案 A · 保存时的输入</span><span>方案 B · 当前输入</span></div>'+now.map(function(m,i){var a=saved.metrics[i].text,b=m.text,an=parseFloat(a),bn=parseFloat(b),valid=Number.isFinite(an)&&Number.isFinite(bn),max=valid?Math.max(Math.abs(an),Math.abs(bn),1):1;return '<div class="compare-row"><b>'+m.label+'</b><div><span>'+safe(a)+'</span>'+(valid?'<i class="compare-bar a" style="width:'+Math.max(1,Math.abs(an)/max*100)+'%"></i>':'')+'</div><div><span>'+safe(b)+'</span>'+(valid?'<i class="compare-bar b" style="width:'+Math.max(1,Math.abs(bn)/max*100)+'%"></i>':'')+'</div><small>'+(a===b?'相同':valid?'变化 '+(bn-an>=0?'+':'')+(bn-an).toFixed(2):'结果变化')+'</small></div>';}).join('')+'<div class="compare-conditions"><p><b>A 条件：</b>'+safe(conditionText(saved.inputs))+'</p><p><b>B 条件：</b>'+safe(conditionText(Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})))+'</p></div><p class="comparison-boundary">对比当前演示的实际显示结果；数值变化不自动代表工程更优。概率 / 分数、余量、覆盖率需结合方法边界分别解释。</p>';}
  root.querySelectorAll('[data-lab-preset]').forEach(function(button){button.addEventListener('click',function(){var preset=config.presets[Number(button.dataset.labPreset)];if(scene==='d2'){var pause=document.getElementById('pause');if(pause)pause.click();if(preset[2].scenario)document.querySelector('[data-scenario="'+preset[2].scenario+'"]').click();}Object.keys(preset[2]).forEach(function(id){if(id==='scenario')return;var input=document.getElementById(id);if(input){input.value=preset[2][id];input.dispatchEvent(new Event('input',{bubbles:true}));}});root.querySelectorAll('[data-lab-preset]').forEach(function(b){b.classList.toggle('on',b===button);b.setAttribute('aria-pressed',String(b===button));});document.getElementById('guided-instruction').textContent='正在观察：'+preset[0]+'。'+preset[1]+'。下方图表、指标和模型依据已重新计算。';compare();});});
  root.querySelector('#save-lab-baseline').addEventListener('click',function(){saved={metrics:measure(),inputs:Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})};this.textContent='更新方案 A';document.getElementById('clear-lab-baseline').hidden=false;document.getElementById('guided-instruction').textContent='已保存方案 A。现在选择另一工况或调整参数，观察 B 的变化。';compare();});
  root.querySelector('#clear-lab-baseline').addEventListener('click',function(){saved=null;document.getElementById('lab-comparison').hidden=true;this.hidden=true;document.getElementById('save-lab-baseline').textContent='保存当前为方案 A';});
  document.addEventListener('input',function(e){if(e.target.matches('input[type=range]'))requestAnimationFrame(compare);});
  window.LabCompare={refresh:compare};
})();
/* final-lab-interactions:end */


/* ai-proof:start */
(function(){
  'use strict';var NS='http://www.w3.org/2000/svg',current=null,mode='calculation';
  function el(tag,attrs,parent,text){var n=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;parent.appendChild(n);return n;}
  function draw(){if(!current)return;var c=current,s=document.getElementById('ai-proof-chart');if(!s)return;s.textContent='';var narrow=innerWidth<620,W=narrow?360:Math.max(460,Math.min(760,s.getBoundingClientRect().width||760));s.setAttribute('viewBox','0 0 '+W+' 252');
    var left=narrow?112:176,right=W-72,top=40,height=160;
    document.getElementById('ai-proof-live').textContent=c.detail;
    document.getElementById('ai-proof-caption').textContent=mode==='comparison'?c.comparisonNote:c.note;
    if(mode==='calculation'&&c.points){
      left=44;right=W-35;var colors=['#2e8064','#b08a3e','#b66647'];
      [0,.5,1].forEach(function(v){var x=left+v*(right-left),y=top+(1-v)*height;el('path',{d:'M'+x+' '+top+'V'+(top+height)+'M'+left+' '+y+'H'+right,stroke:'#e1e8dd',fill:'none'},s);el('text',{x:x,y:top+height+18,'text-anchor':'middle',fill:'#7d8e7c','font-size':10},s,v);});
      c.points.forEach(function(p){el('circle',{cx:left+p.x*(right-left),cy:top+(1-p.y)*height,r:2.5,fill:colors[p.cls],opacity:.65},s);});
      c.centers.forEach(function(p,i){var x=left+p[0]*(right-left),y=top+(1-p[1])*height;el('line',{x1:left+c.selected[0]*(right-left),y1:top+(1-c.selected[1])*height,x2:x,y2:y,stroke:colors[i],'stroke-dasharray':'4 4'},s);el('path',{d:'M'+(x-5)+' '+y+'h10M'+x+' '+(y-5)+'v10',stroke:colors[i],'stroke-width':3},s);});
      el('circle',{cx:left+c.selected[0]*(right-left),cy:top+(1-c.selected[1])*height,r:6,fill:'#183f2d',stroke:'#fff','stroke-width':2},s);el('text',{x:W/2,y:245,'text-anchor':'middle',fill:'#607b63','font-size':10},s,'横轴：CBL 归一化特征 · 纵轴：VDL 特征 · 十字：训练中心');
    }else{
      var bars=mode==='comparison'?c.comparison:c.bars;var max=c.fixedMax||Math.max.apply(null,bars.map(function(b){return Math.abs(b.value);}).concat([.001]));var rowH=Math.min(37,180/bars.length);
      bars.forEach(function(b,i){var y=top+i*rowH,bar=Math.min(1,Math.abs(b.value)/max)*(right-left);el('text',{x:left-10,y:y+11,'text-anchor':'end',fill:'#62775f','font-size':narrow?10:11},s,b.label);el('rect',{x:left,y:y,width:right-left,height:15,rx:2,fill:'#edf1e7'},s);el('rect',{x:left,y:y,width:Math.max(.5,bar),height:15,rx:2,fill:b.value<0?'#b37450':i===0&&mode==='comparison'?'#98a78c':'#3c8060'},s);el('text',{x:right+8,y:y+12,fill:'#3f6749','font-size':11},s,(b.value<0?'−':'')+Math.abs(b.value).toFixed(c.digits==null?2:c.digits)+(c.unit||''));});
      el('text',{x:left,y:235,fill:'#8a987f','font-size':10},s,mode==='comparison'?'同一组对照条件 · '+(c.comparisonUnit||''):c.axis||'柱长表示该项数值大小；符号见右侧');
    }
  }
  window.AIProof={update:function(c){current=c;draw();if(window.LabCompare)requestAnimationFrame(window.LabCompare.refresh);}};
  document.addEventListener('click',function(e){var b=e.target.closest('[data-proof-mode]');if(!b)return;mode=b.dataset.proofMode;document.querySelectorAll('[data-proof-mode]').forEach(function(n){var on=n===b;n.classList.toggle('on',on);n.setAttribute('aria-pressed',String(on));});draw();});
  window.addEventListener('resize',draw);
})();
/* ai-proof:end */

(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var N = 120;
  var COLORS = { ink: '#1e302c', muted: '#697a74', faint: '#8c9994', grid: '#e2e9e5', jade: '#2d7968', blue: '#32799d', gold: '#a6813b', clay: '#bd6841' };
  var state = { scenario: 'normal', threshold: 0.62, index: 0, timer: null };
  var out = {
    threshold: document.getElementById('threshold-output'), time: document.getElementById('time-output'), status: document.getElementById('status'),
    statusDetail: document.getElementById('status-detail'), score: document.getElementById('anomaly-score'), persistence: document.getElementById('persistence'),
    top: document.getElementById('top-channel'), channelDetail: document.getElementById('channel-detail'), chartNote: document.getElementById('chart-note'),
    explanation: document.getElementById('explanation'), eventBand: document.getElementById('event-band'), eventCursor: document.getElementById('event-cursor'), eventLabel: document.getElementById('event-label')
  };
  var chart = document.getElementById('timeseries-chart');
  var contribution = document.getElementById('contribution-chart');
  var slider = document.getElementById('time-index');
  var random = seeded(20261028);
  var data = { normal: generate('normal'), loss: generate('loss') };
  // Learn normal feature means and variances from a separate 60-window training segment.
  var baseline = learnBaseline(data.normal.slice(0, 60));
  function rawFeatures(rows, i) {
    var row=rows[i], prev=rows[Math.max(0,i-5)];
    return [row.flowIn-row.flowOut,row.pit,row.pressure,row.torque-prev.torque];
  }
  function learnBaseline(rows) {
    var values=rows.map(function(_,i){return rawFeatures(rows,i);});
    var mean=[0,1,2,3].map(function(j){return values.reduce(function(s,x){return s+x[j];},0)/values.length;});
    var scale=mean.map(function(m,j){return Math.max(.01,Math.sqrt(values.reduce(function(s,x){return s+Math.pow(x[j]-m,2);},0)/(values.length-1)));});
    return {mean:mean,scale:scale,count:values.length};
  }
  function scoreFeatures(x) {
    var z=x.map(function(v,j){return (v-baseline.mean[j])/baseline.scale[j];});
    var squares=z.map(function(v){return v*v;});
    var distance=squares.reduce(function(s,v){return s+v;},0)/4;
    return {z:z,score:1-Math.exp(-distance/8),residuals:squares.map(function(v){return v/(squares.reduce(function(s,a){return s+a;},0)||1);})};
  }

  function seeded(seed) { var n = seed >>> 0; return function () { n = (1664525 * n + 1013904223) >>> 0; return n / 4294967296; }; }
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function fmt(value, digits) { return Number(value).toFixed(digits); }
  function svg(tag, attrs, parent, text) {
    var node = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    if (text != null) node.textContent = text;
    if (parent) parent.appendChild(node);
    return node;
  }
  function generate(kind) {
    var rows = [];
    for (var i = 0; i < N; i++) {
      var wave = Math.sin(i / 7) * 0.45 + Math.sin(i / 17) * 0.28;
      var event = kind === 'loss' ? clamp((i - 68) / 35, 0, 1) : 0;
      var pitStep = kind === 'loss' && i >= 82 ? Math.min(1, (i - 82) / 22) : 0;
      rows.push({
        t: i,
        flowIn: 72 + wave * 2.7 + (random() - 0.5) * 1.8,
        flowOut: 71.5 + wave * 2.6 + (random() - 0.5) * 2.2 - event * 22,
        pit: 34 + Math.sin(i / 13) * 0.25 + (random() - 0.5) * 0.13 - pitStep * 2.2,
        pressure: 18.5 + Math.sin(i / 10) * 0.42 + (random() - 0.5) * 0.38 - event * 1.25,
        torque: 12.2 + Math.sin(i / 8) * 0.62 + (random() - 0.5) * 0.56 + event * 1.8,
        event: event
      });
    }
    return rows;
  }
  function featuresAt(index) {
    var rows = data[state.scenario];
    var row = rows[index];
    var learned=scoreFeatures(rawFeatures(rows,index));
    return { row: row, residuals: learned.residuals, z:learned.z, score: learned.score, flowGap: row.flowIn - row.flowOut, pitDelta: row.pit - baseline.mean[1] };
  }
  function timeLabel(index) {
    var seconds = index * 10;
    return String(Math.floor(seconds / 60)).padStart(2, '0') + ':' + String(seconds % 60).padStart(2, '0');
  }
  function segmentsPath(rows, key, x, y) {
    return rows.map(function (r, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(r[key]).toFixed(1); }).join(' ');
  }
  function renderChart() {
    chart.textContent = '';
    var width = 920, left = 110, right = 904, top = 28, trackH = 86, gap = 16;
    var rows = data[state.scenario];
    var x = function (i) { return left + i / (N - 1) * (right - left); };
    var tracks = [
      { key: 'flowIn', other: 'flowOut', name: '流量', unit: 'L/s', color: COLORS.jade, min: 38, max: 82, band: [68, 76], secondColor: COLORS.blue, fmt: function (r) { return fmt(r.flowIn, 1) + ' / ' + fmt(r.flowOut, 1); } },
      { key: 'pit', name: '泥浆池体积', unit: 'm³', color: COLORS.blue, min: 31.3, max: 34.7, band: [33.7, 34.3], fmt: function (r) { return fmt(r.pit, 2); } },
      { key: 'pressure', name: '立管压力', unit: 'MPa', color: COLORS.gold, min: 16.3, max: 19.7, band: [17.7, 19.3], fmt: function (r) { return fmt(r.pressure, 2); } },
      { key: 'torque', name: '钻柱扭矩', unit: 'kN·m', color: COLORS.clay, min: 10.0, max: 15.8, band: [11.1, 13.3], fmt: function (r) { return fmt(r.torque, 2); } }
    ];
    var eventStart = 68, eventEnd = 103;
    var eventX = x(eventStart), eventW = x(eventEnd) - eventX;
    if (state.scenario === 'loss') svg('rect', { x: eventX, y: top - 9, width: eventW, height: 4 * trackH + 3 * gap + 18, fill: '#f6eae3', opacity: 0.7 }, chart);

    tracks.forEach(function (track, ti) {
      var y0 = top + ti * (trackH + gap);
      var yy = function (value) { return y0 + trackH - (value - track.min) / (track.max - track.min) * trackH; };
      var bandTop = yy(track.band[1]), bandBottom = yy(track.band[0]);
      svg('rect', { x: left, y: bandTop, width: right - left, height: Math.max(1, bandBottom - bandTop), fill: '#e5f0ec' }, chart);
      [0, 0.5, 1].forEach(function (f) {
        var gy = y0 + f * trackH;
        svg('line', { x1: left, y1: gy, x2: right, y2: gy, stroke: COLORS.grid, 'stroke-width': 1 }, chart);
      });
      svg('text', { x: 8, y: y0 + 28, fill: COLORS.ink, 'font-size': 10, 'font-weight': 600, 'font-family': 'sans-serif' }, chart, track.name);
      svg('text', { x: 8, y: y0 + 43, fill: COLORS.faint, 'font-size': 8, 'font-family': 'sans-serif' }, chart, track.unit);
      svg('text', { x: left - 7, y: y0 + 5, 'text-anchor': 'end', fill: COLORS.faint, 'font-size': 8, 'font-family': 'sans-serif' }, chart, fmt(track.max, 1));
      svg('text', { x: left - 7, y: y0 + trackH, 'text-anchor': 'end', fill: COLORS.faint, 'font-size': 8, 'font-family': 'sans-serif' }, chart, fmt(track.min, 1));
      svg('path', { d: segmentsPath(rows, track.key, x, yy), fill: 'none', stroke: track.color, 'stroke-width': 1.7, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, chart);
      if (track.other) svg('path', { d: segmentsPath(rows, track.other, x, yy), fill: 'none', stroke: track.secondColor, 'stroke-width': 1.6, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, chart);
      var current = rows[state.index];
      svg('circle', { cx: x(state.index), cy: yy(current[track.key]), r: 3.7, fill: '#fff', stroke: track.color, 'stroke-width': 2 }, chart);
      if (ti === 0) svg('circle', { cx: x(state.index), cy: yy(current.flowOut), r: 3.3, fill: track.secondColor, stroke: '#fff', 'stroke-width': 1 }, chart);
      svg('text', { x: right, y: y0 + 11, 'text-anchor': 'end', fill: track.color, 'font-size': 8, 'font-family': 'sans-serif' }, chart, track.fmt(current));
    });
    var cursorX = x(state.index), chartBottom = top + 4 * trackH + 3 * gap;
    svg('line', { x1: cursorX, y1: top - 9, x2: cursorX, y2: chartBottom + 4, stroke: COLORS.ink, 'stroke-width': 1.2, 'stroke-dasharray': '4 3' }, chart);
    [0, 20, 40, 60, 80, 100, 119].forEach(function (tick) {
      svg('text', { x: x(tick), y: chartBottom + 19, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 8, 'font-family': 'sans-serif' }, chart, timeLabel(tick));
    });
    svg('text', { x: right, y: 466, 'text-anchor': 'end', fill: COLORS.faint, 'font-size': 8, 'font-family': 'sans-serif' }, chart, '时间 · mm:ss');
  }
  function renderContribution(info) {
    contribution.textContent = '';
    var names = ['流入—返出差', '池体积变化', '立管压力偏离', '扭矩变化'];
    var colors = [COLORS.jade, COLORS.blue, COLORS.gold, COLORS.clay];
    var left = 133, right = 454, top = 28, rowH = 43;
    [0, 0.25, 0.5, 0.75, 1].forEach(function (tick) {
      var xx = left + tick * (right - left);
      svg('line', { x1: xx, y1: 17, x2: xx, y2: 207, stroke: COLORS.grid }, contribution);
      svg('text', { x: xx, y: 223, 'text-anchor': 'middle', fill: COLORS.faint, 'font-size': 8, 'font-family': 'sans-serif' }, contribution, fmt(tick, 2));
    });
    info.residuals.forEach(function (value, i) {
      var y = top + i * rowH;
      svg('text', { x: left - 8, y: y + 12, 'text-anchor': 'end', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, contribution, names[i]);
      svg('rect', { x: left, y: y, width: right - left, height: 15, rx: 2, fill: '#edf1ef' }, contribution);
      svg('rect', { x: left, y: y, width: Math.max(1, value * (right - left)), height: 15, rx: 2, fill: colors[i] }, contribution);
      svg('text', { x: Math.min(right - 1, left + value * (right - left) + 6), y: y + 11, fill: COLORS.ink, 'font-size': 8, 'font-family': 'sans-serif' }, contribution, fmt(value, 2));
    });
  }
  function updateSummary(info) {
    var over = info.score >= state.threshold;
    var windowStart = Math.max(0, state.index - 5);
    var persistence = 0;
    for (var i = state.index; i >= windowStart; i--) {
      if (featuresAt(i).score >= state.threshold) persistence++;
      else break;
    }
    var labels = ['流量平衡', '池体积', '立管压力', '扭矩'];
    var maxIndex = info.residuals.reduce(function (best, value, i, arr) { return value > arr[best] ? i : best; }, 0);
    document.getElementById('status-panel').dataset.state = over ? 'alert' : 'normal';
    out.status.textContent = over ? (info.row.event > 0.72 ? '异常需立即复核' : '达到预警阈值') : '正常观察';
    out.status.style.color = over ? COLORS.clay : COLORS.jadeDark;
    out.statusDetail.textContent = over ? '检查通道联动、当前工况与传感器状态' : '分数未达到当前阈值，请继续核对各通道';
    out.score.textContent = fmt(info.score, 2);
    out.score.style.color = over ? COLORS.clay : COLORS.ink;
    out.persistence.textContent = persistence + ' / 6';
    out.top.textContent = info.residuals[maxIndex] > 0.08 ? labels[maxIndex] : '无明显偏离';
    out.channelDetail.textContent = '距训练均值 ' + fmt(Math.abs(info.z[maxIndex]), 2) + ' 个标准差';
    out.time.textContent = timeLabel(state.index);
    out.threshold.textContent = fmt(state.threshold, 2);
    slider.value = state.index;
    var pos = state.index / (N - 1) * 100;
    out.eventCursor.style.left = pos + '%';
    if (state.scenario === 'loss') {
      out.eventBand.style.left = (68 / (N - 1) * 100) + '%';
      out.eventBand.style.width = ((103 - 68) / (N - 1) * 100) + '%';
      out.eventLabel.textContent = '返出流量偏低 / 池体积下降';
    } else {
      out.eventBand.style.left = '0'; out.eventBand.style.width = '0'; out.eventLabel.textContent = '无异常事件';
    }
    if (state.scenario === 'normal') {
      out.explanation.textContent = '当前窗口为合成正常钻进。流入与返出流量基本平衡，池体积、立管压力和扭矩仍在该教学基线附近波动。';
    } else if (info.row.event > 0.45) {
      out.explanation.textContent = '返出流量较流入减少约 ' + fmt(Math.max(0, info.flowGap), 1) + ' L/s，池体积较基线变化 ' + fmt(info.pitDelta, 2) + ' m³。多条通道的方向性变化共同推高异常分数；需先核查循环工况和计量可靠性。';
    } else {
      out.explanation.textContent = '合成事件尚处于早期变化阶段。当前游标前方的事件带表示后续偏离窗口；降低报警阈值可更早提示，但通常会增加正常波动误报。';
    }
    if (over && info.row.event > 0.45) out.chartNote.textContent = '当前处于合成异常窗：返出流量相对流入减少，池体积逐渐下降。读图时先核对泵况、返出计量和作业动作，再判断是否升级处置。';
    else if (state.scenario === 'normal') out.chartNote.textContent = '正常工况：各通道围绕合成基线波动。切换“井漏前兆”查看返出流量与池体积逐步偏离。';
    else out.chartNote.textContent = '异常尚未越过当前阈值。播放或移动时间游标，观察多通道变化如何逐渐累积为可复核的异常线索。';
  }
  function render() {
    var info = featuresAt(state.index);
    updateSummary(info);
    renderChart();
    renderContribution(info);
    var holdout=data.normal.slice(60);var fixedFalse=0,learnedFalse=0;for(var j=60;j<N;j++){if(data.normal[j].flowIn-data.normal[j].flowOut>3)fixedFalse++;if(scoreFeatures(rawFeatures(data.normal,j)).score>=state.threshold)learnedFalse++;}
 window.AIProof.update({bars:info.z.map(function(v,i){return {label:['流量差 z','池体积 z','压力 z','扭矩变化 z'][i],value:v};}),detail:'从 '+baseline.count+' 个正常窗口学习 μ、σ。当前 z 值按 (x−μ)/σ 计算；四维平方距离经 1−exp(−d²/8) 映射为 '+info.score.toFixed(3)+'。原通道曲线、贡献和告警共享当前时刻。',note:'柱条来自当前实算标准分数；负值表示低于正常均值，绝对值大表示偏离明显。',comparison:[{label:'流量差固定阈值',value:fixedFalse/60*100},{label:'学习正常基线',value:learnedFalse/60*100}],unit:'%',digits:1,comparisonUnit:'60 个正常留出窗的告警率，越低越好',comparisonNote:'这是正常留出窗的误报对照，不衡量事故召回；降低阈值可能提高误报，不能只看这一个指标。'});
  }
  function pause() { if (state.timer) { clearInterval(state.timer); state.timer = null; } }
  document.querySelectorAll('[data-scenario]').forEach(function (button) {
    button.addEventListener('click', function () {
      pause(); state.scenario = button.getAttribute('data-scenario'); state.index = 0;
      document.querySelectorAll('[data-scenario]').forEach(function (b) { b.classList.toggle('on', b === button); });
      render();
    });
  });
  document.getElementById('threshold').addEventListener('input', function () { state.threshold = Number(this.value) / 100; render(); });
  slider.addEventListener('input', function () { state.index = Number(this.value); render(); });
  document.getElementById('play').addEventListener('click', function () {
    pause();
    state.timer = setInterval(function () {
      state.index = state.index >= N - 1 ? 0 : state.index + 1;
      render();
    }, 150);
  });
  document.getElementById('pause').addEventListener('click', pause);
  document.getElementById('reset-time').addEventListener('click', function () { pause(); state.index = 0; render(); });
  chart.addEventListener('pointerdown', function (event) {
    var rect = chart.getBoundingClientRect();
    var px = (event.clientX - rect.left) * 920 / rect.width;
    var index = Math.round((px - 110) / (904 - 110) * (N - 1));
    if (index < 0 || index >= N) return;
    state.index = index; render();
  });
  window.addEventListener('beforeunload', pause);
  render();
}());

/* final-lab-interactions:start */
(function(){
  'use strict';
  var configs={
    c1:{metrics:[['selected-class','候选类别'],['selected-confidence','相似度置信分'],['review-share','复核比例']],presets:[['良好响应','低振幅与较弱套管波特征',{depth:24,confidence:72}],['过渡区间','检查靠近分类边界的位置',{depth:72,confidence:92}],['较差响应','比较较强套管波特征',{depth:112,confidence:72}]]},
    c2:{metrics:[['current-efficiency','当前预测效率'],['best-efficiency','候选最高效率'],['frac-margin','破裂压力余量']],presets:[['保守方案','较低排量与适中密度',{density:1400,rate:8,centralization:70}],['高排量试探','检查效率改善是否触及压力约束',{density:1640,rate:20,centralization:70}],['改善居中度','固定密度排量，只改变几何条件',{density:1500,rate:13,centralization:95}]]},
    c3:{metrics:[['risk-probability','模型风险分数'],['risk-level','当前风险提示'],['recall-score','留出样本召回率']],presets:[['宽窗口','余量充足，邻井历史频率低',{'window-width':75,'ecd-margin':24,'history-rate':0,'decision-threshold':45}],['窄窗口','多因素叠加，观察贡献变化',{'window-width':25,'ecd-margin':3,'history-rate':45,'decision-threshold':45}],['提高阈值','固定井况，区分分数与决策',{'window-width':42,'ecd-margin':10,'history-rate':18,'decision-threshold':70}]]},
    c4:{metrics:[['min-after','方案最小居中度'],['coverage-after','目标覆盖率'],['used-count','扶正器数量']],presets:[['无扶正器','建立原始几何对照',{eccentricity:55,target:65,'max-centralizers':0,depth:120}],['布置五个','在数量约束下搜索薄弱段',{eccentricity:55,target:65,'max-centralizers':5,depth:120}],['增加上限','观察新增位置是否仍有收益',{eccentricity:55,target:65,'max-centralizers':8,depth:120}]]},
    d2:{metrics:[['anomaly-score','异常分数'],['persistence','超限持续窗'],['top-channel','贡献最大通道']],presets:[['正常留出窗','正常工况下也应检查误报',{scenario:'normal','time-index':100,threshold:62}],['井漏前兆','让多个通道共同参与判断',{scenario:'loss','time-index':100,threshold:62}],['降低阈值','相同早期时刻，调整决策灵敏度',{scenario:'loss','time-index':80,threshold:35}]]}
  };
  var scene=document.querySelector('main').dataset.scene,config=configs[scene];if(!config)return;
  var root=document.getElementById('lab-interactions');if(!root)return;
  root.innerHTML='<div class="guided-top"><div><span>EXPERIMENT / 自己动手验证</span><h2>先选工况，再保存一组对照。</h2></div><span class="guided-index">'+(scene==='d2'?'拓展实验':'固井实验')+'</span></div><div class="guided-presets">'+config.presets.map(function(p,i){return '<button type="button" data-lab-preset="'+i+'" aria-pressed="false"><b>0'+(i+1)+'</b><span>'+p[0]+'<small>'+p[1]+'</small></span><i>↗</i></button>';}).join('')+'</div><div class="comparison-tools"><p id="guided-instruction">点击一种典型工况；保存为 A 后，调整下方参数查看 A / B 对比。</p><button type="button" id="save-lab-baseline">保存当前为方案 A</button><button type="button" id="clear-lab-baseline" hidden>清除对照</button></div><div id="lab-comparison" hidden aria-live="polite"></div>';
  var saved=null;
  function measure(){return config.metrics.map(function(m){var node=document.getElementById(m[0]);return {label:m[1],text:node?node.textContent.trim():'—'};});}
  function safe(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function conditionText(inputs){var names={confidence:'最低置信 %',depth:'测深 m',density:'密度 kg/m³',rate:'排量 L/s',centralization:'居中度 %','window-width':'窗口宽度 ×0.01 g/cm³','ecd-margin':'ECD 余量 ×0.01 g/cm³','history-rate':'历史频率 %','decision-threshold':'预警阈值 %',eccentricity:'偏心 %',target:'目标 %','max-centralizers':'数量上限',threshold:'阈值 %','time-index':'时间窗索引'};return inputs.map(function(x){return (names[x.id]||x.id)+' '+x.value;}).join(' · ');}
  function compare(){if(!saved)return;var now=measure(),out=document.getElementById('lab-comparison');out.hidden=false;out.innerHTML='<div class="compare-intro"><span>方案 A · 保存时的输入</span><span>方案 B · 当前输入</span></div>'+now.map(function(m,i){var a=saved.metrics[i].text,b=m.text,an=parseFloat(a),bn=parseFloat(b),valid=Number.isFinite(an)&&Number.isFinite(bn),max=valid?Math.max(Math.abs(an),Math.abs(bn),1):1;return '<div class="compare-row"><b>'+m.label+'</b><div><span>'+safe(a)+'</span>'+(valid?'<i class="compare-bar a" style="width:'+Math.max(1,Math.abs(an)/max*100)+'%"></i>':'')+'</div><div><span>'+safe(b)+'</span>'+(valid?'<i class="compare-bar b" style="width:'+Math.max(1,Math.abs(bn)/max*100)+'%"></i>':'')+'</div><small>'+(a===b?'相同':valid?'变化 '+(bn-an>=0?'+':'')+(bn-an).toFixed(2):'结果变化')+'</small></div>';}).join('')+'<div class="compare-conditions"><p><b>A 条件：</b>'+safe(conditionText(saved.inputs))+'</p><p><b>B 条件：</b>'+safe(conditionText(Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})))+'</p></div><p class="comparison-boundary">对比当前演示的实际显示结果；数值变化不自动代表工程更优。概率 / 分数、余量、覆盖率需结合方法边界分别解释。</p>';}
  root.querySelectorAll('[data-lab-preset]').forEach(function(button){button.addEventListener('click',function(){var preset=config.presets[Number(button.dataset.labPreset)];if(scene==='d2'){var pause=document.getElementById('pause');if(pause)pause.click();if(preset[2].scenario)document.querySelector('[data-scenario="'+preset[2].scenario+'"]').click();}Object.keys(preset[2]).forEach(function(id){if(id==='scenario')return;var input=document.getElementById(id);if(input){input.value=preset[2][id];input.dispatchEvent(new Event('input',{bubbles:true}));}});root.querySelectorAll('[data-lab-preset]').forEach(function(b){b.classList.toggle('on',b===button);b.setAttribute('aria-pressed',String(b===button));});document.getElementById('guided-instruction').textContent='正在观察：'+preset[0]+'。'+preset[1]+'。下方图表、指标和模型依据已重新计算。';compare();});});
  root.querySelector('#save-lab-baseline').addEventListener('click',function(){saved={metrics:measure(),inputs:Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})};this.textContent='更新方案 A';document.getElementById('clear-lab-baseline').hidden=false;document.getElementById('guided-instruction').textContent='已保存方案 A。现在选择另一工况或调整参数，观察 B 的变化。';compare();});
  root.querySelector('#clear-lab-baseline').addEventListener('click',function(){saved=null;document.getElementById('lab-comparison').hidden=true;this.hidden=true;document.getElementById('save-lab-baseline').textContent='保存当前为方案 A';});
  document.addEventListener('input',function(e){if(e.target.matches('input[type=range]'))requestAnimationFrame(compare);});
  window.LabCompare={refresh:compare};
})();
/* final-lab-interactions:end */


/* ai-proof:start */
(function(){
  'use strict';var NS='http://www.w3.org/2000/svg',current=null,mode='calculation';
  function el(tag,attrs,parent,text){var n=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;parent.appendChild(n);return n;}
  function draw(){if(!current)return;var c=current,s=document.getElementById('ai-proof-chart');if(!s)return;s.textContent='';var narrow=innerWidth<620,W=narrow?360:Math.max(460,Math.min(760,s.getBoundingClientRect().width||760));s.setAttribute('viewBox','0 0 '+W+' 252');
    var left=narrow?112:176,right=W-72,top=40,height=160;
    document.getElementById('ai-proof-live').textContent=c.detail;
    document.getElementById('ai-proof-caption').textContent=mode==='comparison'?c.comparisonNote:c.note;
    if(mode==='calculation'&&c.points){
      left=44;right=W-35;var colors=['#2e8064','#b08a3e','#b66647'];
      [0,.5,1].forEach(function(v){var x=left+v*(right-left),y=top+(1-v)*height;el('path',{d:'M'+x+' '+top+'V'+(top+height)+'M'+left+' '+y+'H'+right,stroke:'#e1e8dd',fill:'none'},s);el('text',{x:x,y:top+height+18,'text-anchor':'middle',fill:'#7d8e7c','font-size':10},s,v);});
      c.points.forEach(function(p){el('circle',{cx:left+p.x*(right-left),cy:top+(1-p.y)*height,r:2.5,fill:colors[p.cls],opacity:.65},s);});
      c.centers.forEach(function(p,i){var x=left+p[0]*(right-left),y=top+(1-p[1])*height;el('line',{x1:left+c.selected[0]*(right-left),y1:top+(1-c.selected[1])*height,x2:x,y2:y,stroke:colors[i],'stroke-dasharray':'4 4'},s);el('path',{d:'M'+(x-5)+' '+y+'h10M'+x+' '+(y-5)+'v10',stroke:colors[i],'stroke-width':3},s);});
      el('circle',{cx:left+c.selected[0]*(right-left),cy:top+(1-c.selected[1])*height,r:6,fill:'#183f2d',stroke:'#fff','stroke-width':2},s);el('text',{x:W/2,y:245,'text-anchor':'middle',fill:'#607b63','font-size':10},s,'横轴：CBL 归一化特征 · 纵轴：VDL 特征 · 十字：训练中心');
    }else{
      var bars=mode==='comparison'?c.comparison:c.bars;var max=c.fixedMax||Math.max.apply(null,bars.map(function(b){return Math.abs(b.value);}).concat([.001]));var rowH=Math.min(37,180/bars.length);
      bars.forEach(function(b,i){var y=top+i*rowH,bar=Math.min(1,Math.abs(b.value)/max)*(right-left);el('text',{x:left-10,y:y+11,'text-anchor':'end',fill:'#62775f','font-size':narrow?10:11},s,b.label);el('rect',{x:left,y:y,width:right-left,height:15,rx:2,fill:'#edf1e7'},s);el('rect',{x:left,y:y,width:Math.max(.5,bar),height:15,rx:2,fill:b.value<0?'#b37450':i===0&&mode==='comparison'?'#98a78c':'#3c8060'},s);el('text',{x:right+8,y:y+12,fill:'#3f6749','font-size':11},s,(b.value<0?'−':'')+Math.abs(b.value).toFixed(c.digits==null?2:c.digits)+(c.unit||''));});
      el('text',{x:left,y:235,fill:'#8a987f','font-size':10},s,mode==='comparison'?'同一组对照条件 · '+(c.comparisonUnit||''):c.axis||'柱长表示该项数值大小；符号见右侧');
    }
  }
  window.AIProof={update:function(c){current=c;draw();if(window.LabCompare)requestAnimationFrame(window.LabCompare.refresh);}};
  document.addEventListener('click',function(e){var b=e.target.closest('[data-proof-mode]');if(!b)return;mode=b.dataset.proofMode;document.querySelectorAll('[data-proof-mode]').forEach(function(n){var on=n===b;n.classList.toggle('on',on);n.setAttribute('aria-pressed',String(on));});draw();});
  window.addEventListener('resize',draw);
})();
/* ai-proof:end */

(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var TVD = 2100;
  var PORE_GRADIENT = 12.8;
  var FRAC_GRADIENT = 16.4;
  var COLORS = { ink: '#1e302c', muted: '#697a74', faint: '#8c9994', grid: '#e2e9e5', blue: '#32799d', jade: '#2d7968', jadeDark: '#205b4d', gold: '#a6813b', clay: '#bd6841' };
  var controls = {
    density: document.getElementById('density'),
    rate: document.getElementById('rate'),
    centralization: document.getElementById('centralization')
  };
  var output = {
    density: document.getElementById('density-output'), rate: document.getElementById('rate-output'), centralization: document.getElementById('centralization-output'),
    currentEfficiency: document.getElementById('current-efficiency'), bestEfficiency: document.getElementById('best-efficiency'), delta: document.getElementById('efficiency-delta'),
    margin: document.getElementById('frac-margin'), r2: document.getElementById('r2'), pressureNote: document.getElementById('pressure-note')
  };
  var pressureChart = document.getElementById('pressure-chart');
  var designMap = document.getElementById('design-map');
  var fitChart = document.getElementById('fit-chart');
  var random = makeRandom(2406010106);
  var dataset = makeDataset(240);
  var model = train(dataset);
  var testRows = dataset.filter(function (row) { return !row.train; });
  var state = { density: 1500, rate: 13, centralization: 0.70, best: null };
  var densityValues = range(1300, 1680, 25);
  var rateValues = range(6, 20, 1);

  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function range(start, end, step) { var out = []; for (var v = start; v <= end; v += step) out.push(v); return out; }
  function makeRandom(seed) { var n = seed >>> 0; return function () { n = (1664525 * n + 1013904223) >>> 0; return n / 4294967296; }; }
  function svg(tag, attrs, parent, value) {
    var node = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    if (value != null) node.textContent = value;
    if (parent) parent.appendChild(node);
    return node;
  }
  function fmt(value, digits) { return Number(value).toFixed(digits); }
  function normalized(row) {
    var d = (row.density - 1490) / 190;
    var q = (row.rate - 6) / 14;
    var c = (row.centralization - 0.35) / 0.60;
    return [1, d, q, c, d * q, q * q];
  }
  function referenceEfficiency(row) {
    var d = (row.density - 1490) / 190;
    var q = (row.rate - 6) / 14;
    var c = (row.centralization - 0.35) / 0.60;
    var interaction = 0.045 * d * q;
    var noise = (row.noise || 0) * 0.07;
    return clamp(0.59 + 0.105 * d + 0.175 * q + 0.16 * c + interaction - 0.048 * q * q + noise, 0.25, 0.96);
  }
  function makeDataset(count) {
    var rows = [];
    for (var i = 0; i < count; i++) {
      var row = {
        density: 1300 + random() * 380,
        rate: 6 + random() * 14,
        centralization: 0.35 + random() * 0.60,
        noise: random() - 0.5,
        train: i % 5 !== 0
      };
      row.target = referenceEfficiency(row);
      rows.push(row);
    }
    return rows;
  }
  function solve(matrix, vector) {
    var a = matrix.map(function (row, i) { return row.slice().concat([vector[i]]); });
    var n = vector.length;
    for (var col = 0; col < n; col++) {
      var pivot = col;
      for (var row = col + 1; row < n; row++) if (Math.abs(a[row][col]) > Math.abs(a[pivot][col])) pivot = row;
      var tmp = a[col]; a[col] = a[pivot]; a[pivot] = tmp;
      var divisor = a[col][col] || 1e-9;
      for (var j = col; j <= n; j++) a[col][j] /= divisor;
      for (var r = 0; r < n; r++) {
        if (r === col) continue;
        var factor = a[r][col];
        for (var k = col; k <= n; k++) a[r][k] -= factor * a[col][k];
      }
    }
    return a.map(function (row) { return row[n]; });
  }
  function fit(rows) {
    var width = 6;
    var xtx = Array.from({ length: width }, function () { return Array(width).fill(0); });
    var xty = Array(width).fill(0);
    rows.forEach(function (row) {
      var x = normalized(row);
      for (var i = 0; i < width; i++) {
        xty[i] += x[i] * row.target;
        for (var j = 0; j < width; j++) xtx[i][j] += x[i] * x[j];
      }
    });
    return solve(xtx, xty);
  }
  function predict(row, coeffs) {
    var x = normalized(row);
    return clamp(coeffs.reduce(function (sum, coef, i) { return sum + coef * x[i]; }, 0), 0, 1);
  }
  function train(rows) {
    var trainRows = rows.filter(function (r) { return r.train; });
    var holdout = rows.filter(function (r) { return !r.train; });
    var coeffs = fit(trainRows);
    var avg = holdout.reduce(function (s, r) { return s + r.target; }, 0) / holdout.length;
    var ssTot = 0, ssRes = 0, squared = 0;
    holdout.forEach(function (r) {
      var error = r.target - predict(r, coeffs);
      ssRes += error * error;
      ssTot += Math.pow(r.target - avg, 2);
      squared += error * error;
    });
    return { coeffs: coeffs, r2: 1 - ssRes / ssTot, rmse: Math.sqrt(squared / holdout.length), count: holdout.length };
  }
  function pressureAt(depth, candidate) {
    var hydrostatic = candidate.density * 9.81 * depth / 1000000;
    var frictionTotal = 0.012 * Math.pow(candidate.rate, 1.75);
    return hydrostatic + frictionTotal * depth / TVD;
  }
  function boundsAt(depth) {
    return { pore: PORE_GRADIENT * depth / 1000, frac: FRAC_GRADIENT * depth / 1000 };
  }
  function evaluate(density, rate, centralization) {
    var row = { density: density, rate: rate, centralization: centralization };
    var candidate = { density: density, rate: rate, centralization: centralization, efficiency: predict(row, model.coeffs) };
    var minPoreMargin = Infinity, minFracMargin = Infinity;
    range(300, TVD, 100).forEach(function (depth) {
      var bounds = boundsAt(depth);
      var pressure = pressureAt(depth, candidate);
      minPoreMargin = Math.min(minPoreMargin, pressure - bounds.pore);
      minFracMargin = Math.min(minFracMargin, bounds.frac - pressure);
    });
    candidate.poreMargin = minPoreMargin;
    candidate.fracMargin = minFracMargin;
    candidate.feasible = minPoreMargin >= 0.15 && minFracMargin >= 0.15;
    candidate.score = candidate.efficiency - 0.018 * Math.pow((rate - 6) / 14, 2) - 0.012 / Math.max(minFracMargin, 0.15);
    return candidate;
  }
  function optimize(centralization) {
    var best = null;
    densityValues.forEach(function (density) {
      rateValues.forEach(function (rate) {
        var candidate = evaluate(density, rate, centralization);
        if (candidate.feasible && (!best || candidate.score > best.score)) best = candidate;
      });
    });
    return best;
  }
  function currentCandidate() { return evaluate(state.density, state.rate, state.centralization); }

  function renderMetrics(current) {
    output.density.textContent = state.density + ' kg/m³';
    output.rate.textContent = state.rate + ' L/s';
    output.centralization.textContent = fmt(state.centralization, 2);
    output.currentEfficiency.textContent = Math.round(current.efficiency * 100) + '%';
    output.bestEfficiency.textContent = Math.round(state.best.efficiency * 100) + '%';
    var delta = Math.round((state.best.efficiency - current.efficiency) * 100);
    output.delta.textContent = (delta >= 0 ? '+' : '') + delta + ' 个百分点 · ρ' + state.best.density + ' / Q' + state.best.rate;
    output.margin.textContent = fmt(current.fracMargin, 2) + ' MPa';
    output.margin.style.color = current.fracMargin < 0.8 ? COLORS.clay : COLORS.ink;
    output.r2.textContent = fmt(model.r2, 2);
    if (!current.feasible) {
      output.pressureNote.textContent = '当前组合不满足压力筛选裕度：' + (current.poreMargin < 0.15 ? '低于孔隙压力下限。' : '') + (current.fracMargin < 0.15 ? '接近或超过破裂压力安全边界。' : '') + ' 推荐标记显示搜索得到的可行候选。';
    } else {
      output.pressureNote.textContent = '当前组合位于演示压力窗口内。推荐点为搜索评分更高的候选方案；颜色与边界均基于教学简化计算。';
    }
  }
  function renderPressure(current) {
    pressureChart.textContent = '';
    var left = 66, right = 710, top = 25, bottom = 244, maxP = 42;
    var x = function (p) { return left + p / maxP * (right - left); };
    var y = function (depth) { return top + depth / TVD * (bottom - top); };
    [0, 10, 20, 30, 40].forEach(function (tick) {
      var xx = x(tick);
      svg('line', { x1: xx, y1: top, x2: xx, y2: bottom, stroke: COLORS.grid }, pressureChart);
      svg('text', { x: xx, y: bottom + 18, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, String(tick));
    });
    [0, 500, 1000, 1500, 2000, TVD].forEach(function (tick) {
      var yy = y(tick);
      svg('line', { x1: left, y1: yy, x2: right, y2: yy, stroke: COLORS.grid }, pressureChart);
      svg('text', { x: left - 10, y: yy + 3, 'text-anchor': 'end', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, String(tick));
    });
    svg('text', { x: (left + right) / 2, y: 285, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, '压力 MPa');
    svg('text', { x: 14, y: (top + bottom) / 2, transform: 'rotate(-90 14 ' + ((top + bottom) / 2) + ')', 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, '测深 TVD m');
    var pore = [], frac = [], currentPath = [], bestPath = [];
    range(0, TVD, 100).forEach(function (depth) {
      var b = boundsAt(depth);
      pore.push((pore.length ? 'L' : 'M') + x(b.pore).toFixed(1) + ' ' + y(depth).toFixed(1));
      frac.push((frac.length ? 'L' : 'M') + x(b.frac).toFixed(1) + ' ' + y(depth).toFixed(1));
      currentPath.push((currentPath.length ? 'L' : 'M') + x(pressureAt(depth, current)).toFixed(1) + ' ' + y(depth).toFixed(1));
      bestPath.push((bestPath.length ? 'L' : 'M') + x(pressureAt(depth, state.best)).toFixed(1) + ' ' + y(depth).toFixed(1));
    });
    svg('path', { d: pore.join(' '), fill: 'none', stroke: COLORS.blue, 'stroke-width': 2.4 }, pressureChart);
    svg('path', { d: frac.join(' '), fill: 'none', stroke: COLORS.clay, 'stroke-width': 2.4 }, pressureChart);
    svg('path', { d: currentPath.join(' '), fill: 'none', stroke: COLORS.gold, 'stroke-width': 2.4, 'stroke-dasharray': '6 4' }, pressureChart);
    svg('path', { d: bestPath.join(' '), fill: 'none', stroke: COLORS.jade, 'stroke-width': 3 }, pressureChart);
    var bottomCurrent = pressureAt(TVD, current), bottomBest = pressureAt(TVD, state.best), btm = boundsAt(TVD);
    svg('circle', { cx: x(bottomCurrent), cy: y(TVD), r: 4, fill: '#fff', stroke: COLORS.gold, 'stroke-width': 2 }, pressureChart);
    svg('circle', { cx: x(bottomBest), cy: y(TVD), r: 4, fill: COLORS.jade, stroke: '#fff', 'stroke-width': 1.5 }, pressureChart);
    svg('text', { x: right - 2, y: y(btm.frac) - 7, 'text-anchor': 'end', fill: COLORS.clay, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, '破裂 ' + fmt(btm.frac, 1));
    svg('text', { x: right - 2, y: y(btm.pore) + 13, 'text-anchor': 'end', fill: COLORS.blue, 'font-size': 9, 'font-family': 'sans-serif' }, pressureChart, '孔隙 ' + fmt(btm.pore, 1));
  }
  function mapColor(candidate) {
    if (candidate.poreMargin < 0.15) return '#d9e8ee';
    if (candidate.fracMargin < 0.15) return '#f2ddd3';
    var t = clamp((candidate.score - 0.58) / 0.35, 0, 1);
    var low = [225, 239, 233], high = [45, 121, 104];
    var c = low.map(function (v, i) { return Math.round(v + (high[i] - v) * t); });
    return 'rgb(' + c.join(',') + ')';
  }
  function renderMap() {
    designMap.textContent = '';
    var left = 76, right = 720, top = 25, bottom = 238;
    var cellW = (right - left) / densityValues.length, cellH = (bottom - top) / rateValues.length;
    var x = function (density) { return left + densityValues.indexOf(density) * cellW; };
    var y = function (rate) { return bottom - (rate - 6 + 1) * cellH; };
    rateValues.forEach(function (rate) {
      densityValues.forEach(function (density) {
        var candidate = evaluate(density, rate, state.centralization);
        svg('rect', { x: x(density) + 0.5, y: y(rate) + 0.5, width: cellW - 1, height: cellH - 1, rx: 1, fill: mapColor(candidate), stroke: '#fff', 'stroke-width': 0.6, 'data-density': density, 'data-rate': rate }, designMap);
      });
    });
    svg('rect', { x: left, y: top, width: right - left, height: bottom - top, fill: 'none', stroke: '#aebdb6', 'stroke-width': 1 }, designMap);
    [1300, 1400, 1500, 1600, 1680].forEach(function (density) {
      var nearest = densityValues.reduce(function (a, b) { return Math.abs(b - density) < Math.abs(a - density) ? b : a; }, densityValues[0]);
      var xx = x(nearest) + cellW / 2;
      svg('text', { x: xx, y: bottom + 17, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, designMap, String(density));
    });
    [6, 10, 14, 18, 20].forEach(function (rate) {
      var yy = y(rate) + cellH / 2 + 3;
      svg('text', { x: left - 8, y: yy, 'text-anchor': 'end', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, designMap, String(rate));
    });
    svg('text', { x: (left + right) / 2, y: 278, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, designMap, '等效浆体密度 kg/m³');
    svg('text', { x: 18, y: (top + bottom) / 2, transform: 'rotate(-90 18 ' + ((top + bottom) / 2) + ')', 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, designMap, '泵排量 L/s');
    function marker(candidate, fill, stroke, r) {
      var d = densityValues.reduce(function (a, b) { return Math.abs(b - candidate.density) < Math.abs(a - candidate.density) ? b : a; }, densityValues[0]);
      var q = rateValues.reduce(function (a, b) { return Math.abs(b - candidate.rate) < Math.abs(a - candidate.rate) ? b : a; }, rateValues[0]);
      svg('circle', { cx: x(d) + cellW / 2, cy: y(q) + cellH / 2, r: r, fill: fill, stroke: stroke, 'stroke-width': 2 }, designMap);
    }
    marker(currentCandidate(), '#fff', COLORS.gold, 5);
    marker(state.best, COLORS.jadeDark, '#fff', 4.5);
  }
  function renderFit() {
    fitChart.textContent = '';
    var left = 48, right = 365, top = 17, bottom = 188;
    var x = function (v) { return left + v * (right - left); };
    var y = function (v) { return bottom - v * (bottom - top); };
    [0, 0.25, 0.5, 0.75, 1].forEach(function (tick) {
      svg('line', { x1: x(tick), y1: top, x2: x(tick), y2: bottom, stroke: COLORS.grid }, fitChart);
      svg('line', { x1: left, y1: y(tick), x2: right, y2: y(tick), stroke: COLORS.grid }, fitChart);
      svg('text', { x: x(tick), y: bottom + 15, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 8, 'font-family': 'sans-serif' }, fitChart, fmt(tick, 1));
      svg('text', { x: left - 7, y: y(tick) + 3, 'text-anchor': 'end', fill: COLORS.muted, 'font-size': 8, 'font-family': 'sans-serif' }, fitChart, fmt(tick, 1));
    });
    svg('line', { x1: x(0), y1: y(0), x2: x(1), y2: y(1), stroke: '#9daba4', 'stroke-width': 1.2, 'stroke-dasharray': '4 4' }, fitChart);
    testRows.forEach(function (row) {
      var predicted = predict(row, model.coeffs);
      svg('circle', { cx: x(row.target), cy: y(predicted), r: 2.8, fill: COLORS.blue, opacity: 0.68 }, fitChart);
    });
    svg('text', { x: (left + right) / 2, y: 221, 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, fitChart, '参考效率代理');
    svg('text', { x: 13, y: (top + bottom) / 2, transform: 'rotate(-90 13 ' + ((top + bottom) / 2) + ')', 'text-anchor': 'middle', fill: COLORS.muted, 'font-size': 9, 'font-family': 'sans-serif' }, fitChart, '模型预测');
  }
  function render() {
    state.density = Number(controls.density.value);
    state.rate = Number(controls.rate.value);
    state.centralization = Number(controls.centralization.value) / 100;
    state.best = optimize(state.centralization);
    var current = currentCandidate();
    renderMetrics(current);
    renderPressure(current);
    renderMap();
    renderFit();
    var terms=normalized(current).map(function(x,i){return x*model.coeffs[i];});var trainAvg=dataset.filter(function(r){return r.train;}).reduce(function(s,r){return s+r.target;},0)/192;var baseRMSE=Math.sqrt(testRows.reduce(function(s,r){return s+Math.pow(r.target-trainAvg,2);},0)/testRows.length);
 window.AIProof.update({bars:terms.map(function(v,i){return {label:['截距','密度项','排量项','居中度项','密度×排量','排量平方'][i],value:v*100};}),detail:'学习得到的六项预测贡献相加为 '+(current.efficiency*100).toFixed(1)+'%。当前方案'+(current.feasible?'通过':'未通过')+'压力约束；保留候选才参加收益排序。',note:'柱条为当前标准化输入×训练系数，负项用棕色表示。',comparison:[{label:'固定训练均值',value:baseRMSE*100},{label:'回归代理模型',value:model.rmse*100}],unit:'',comparisonUnit:'留出集 RMSE（百分点），越低越好',comparisonNote:'同 48 个留出合成样本，比较恒定预测与回归预测误差。仅说明对该合成规律的拟合。'});
  }
  function setCandidate(candidate) {
    if (!candidate) return;
    controls.density.value = candidate.density;
    controls.rate.value = candidate.rate;
    render();
  }

  [controls.density, controls.rate, controls.centralization].forEach(function (control) { control.addEventListener('input', render); });
  document.getElementById('apply-best').addEventListener('click', function () { setCandidate(state.best); });
  document.getElementById('reset').addEventListener('click', function () {
    controls.density.value = 1500;
    controls.rate.value = 13;
    controls.centralization.value = 70;
    render();
  });
  designMap.addEventListener('pointerdown', function (event) {
    var rect = designMap.getBoundingClientRect();
    var px = (event.clientX - rect.left) * 760 / rect.width;
    var py = (event.clientY - rect.top) * 300 / rect.height;
    var left = 76, right = 720, top = 25, bottom = 238;
    if (px < left || px > right || py < top || py > bottom) return;
    var di = clamp(Math.floor((px - left) / ((right - left) / densityValues.length)), 0, densityValues.length - 1);
    var ri = clamp(Math.floor((bottom - py) / ((bottom - top) / rateValues.length)), 0, rateValues.length - 1);
    setCandidate(evaluate(densityValues[di], rateValues[ri], state.centralization));
  });
  designMap.addEventListener('pointermove', function (event) {
    var target = event.target.closest('[data-density]');
    designMap.style.cursor = target ? 'crosshair' : 'default';
  });
  window.addEventListener('resize', function () { renderPressure(currentCandidate()); renderMap(); renderFit(); });
  render();
}());

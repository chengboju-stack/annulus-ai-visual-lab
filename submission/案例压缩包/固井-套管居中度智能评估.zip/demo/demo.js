/* final-lab-interactions:start */
(function(){
  'use strict';
  var configs={
    c1:{metrics:[['selected-class','候选类别'],['selected-confidence','相似度置信分'],['review-share','复核比例']],presets:[['良好响应','低振幅与较弱套管波特征',{depth:24,confidence:72}],['过渡区间','检查靠近分类边界的位置',{depth:72,confidence:92}],['较差响应','比较较强套管波特征',{depth:112,confidence:72}]]},
    c2:{metrics:[['current-efficiency','当前预测效率'],['best-efficiency','候选最高效率'],['frac-margin','破裂压力余量']],presets:[['保守方案','较低排量与适中密度',{density:1400,rate:8,centralization:70}],['高排量试探','检查效率改善是否触及压力约束',{density:1640,rate:20,centralization:70}],['改善居中度','固定密度排量，只改变几何条件',{density:1500,rate:13,centralization:95}]]},
    c3:{metrics:[['risk-probability','模型风险分数'],['risk-level','当前风险提示'],['recall-score','留出样本召回率']],presets:[['宽窗口','余量充足，邻井历史频率低',{'window-width':75,'ecd-margin':24,'history-rate':0,'decision-threshold':45}],['窄窗口','多因素叠加，观察贡献变化',{'window-width':25,'ecd-margin':3,'history-rate':45,'decision-threshold':45}],['提高阈值','固定井况，区分分数与决策',{'window-width':42,'ecd-margin':10,'history-rate':18,'decision-threshold':70}]]},
    c4:{metrics:[['min-after','方案最小居中度'],['coverage-after','目标覆盖率'],['used-count','扶正器数量']],presets:[['无扶正器','建立原始几何对照',{eccentricity:55,target:65,'max-centralizers':0,depth:120}],['布置五个','在数量约束下搜索薄弱段',{eccentricity:55,target:65,'max-centralizers':5,depth:120}],['增加上限','观察新增位置是否仍有收益',{eccentricity:55,target:65,'max-centralizers':8,depth:120}]]},
    d2:{metrics:[['anomaly-score','异常分数'],['persistence','超限持续窗'],['top-channel','贡献最大通道']],presets:[['正常留出窗','正常工况下也应检查误报',{scenario:'normal','time-index':100,threshold:62}],['井漏前兆','让多个通道共同参与判断',{scenario:'loss','time-index':100,threshold:62}],['降低阈值','相同早期时刻，调整决策灵敏度',{scenario:'loss','time-index':80,threshold:35}]]}
  };
  var scene=document.querySelector('main').dataset.scene,config=configs[scene];if(!config)return;
  var root=document.getElementById('lab-interactions');if(!root)return;
  root.innerHTML='<div class="guided-top"><div><span>EXPERIMENT / 自己动手验证</span><h2>先选工况，再保存一组对照。</h2></div><span class="guided-index">'+(scene==='d2'?'拓展实验':'固井实验')+'</span></div><div class="guided-presets">'+config.presets.map(function(p,i){return '<button type="button" data-lab-preset="'+i+'" aria-pressed="false"><b>0'+(i+1)+'</b><span>'+p[0]+'<small>'+p[1]+'</small></span><i>↗</i></button>';}).join('')+'</div><div class="comparison-tools"><p id="guided-instruction">点击一种典型工况；保存为 A 后，调整下方参数查看 A / B 对比。</p><button type="button" id="save-lab-baseline">保存当前为方案 A</button><button type="button" id="clear-lab-baseline" hidden>清除对照</button></div><div id="lab-comparison" hidden aria-live="polite"></div>';
  var saved=null;
  function measure(){return config.metrics.map(function(m){var node=document.getElementById(m[0]);return {label:m[1],text:node?node.textContent.trim():'—'};});}
  function safe(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function conditionText(inputs){var names={confidence:'最低置信 %',depth:'测深 m',density:'密度 kg/m³',rate:'排量 L/s',centralization:'居中度 %','window-width':'窗口宽度 ×0.01 g/cm³','ecd-margin':'ECD 余量 ×0.01 g/cm³','history-rate':'历史频率 %','decision-threshold':'预警阈值 %',eccentricity:'偏心 %',target:'目标 %','max-centralizers':'数量上限',threshold:'阈值 %','time-index':'时间窗索引'};return inputs.map(function(x){return (names[x.id]||x.id)+' '+x.value;}).join(' · ');}
  function compare(){if(!saved)return;var now=measure(),out=document.getElementById('lab-comparison');out.hidden=false;out.innerHTML='<div class="compare-intro"><span>方案 A · 保存时的输入</span><span>方案 B · 当前输入</span></div>'+now.map(function(m,i){var a=saved.metrics[i].text,b=m.text,an=parseFloat(a),bn=parseFloat(b),valid=Number.isFinite(an)&&Number.isFinite(bn),max=valid?Math.max(Math.abs(an),Math.abs(bn),1):1;return '<div class="compare-row"><b>'+m.label+'</b><div><span>'+safe(a)+'</span>'+(valid?'<i class="compare-bar a" style="width:'+Math.max(1,Math.abs(an)/max*100)+'%"></i>':'')+'</div><div><span>'+safe(b)+'</span>'+(valid?'<i class="compare-bar b" style="width:'+Math.max(1,Math.abs(bn)/max*100)+'%"></i>':'')+'</div><small>'+(a===b?'相同':valid?'变化 '+(bn-an>=0?'+':'')+(bn-an).toFixed(2):'结果变化')+'</small></div>';}).join('')+'<div class="compare-conditions"><p><b>A 条件：</b>'+safe(conditionText(saved.inputs))+'</p><p><b>B 条件：</b>'+safe(conditionText(Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})))+'</p></div><p class="comparison-boundary">对比当前演示的实际显示结果；数值变化不自动代表工程更优。概率 / 分数、余量、覆盖率需结合方法边界分别解释。</p>';}
  root.querySelectorAll('[data-lab-preset]').forEach(function(button){button.addEventListener('click',function(){var preset=config.presets[Number(button.dataset.labPreset)];if(scene==='d2'){var pause=document.getElementById('pause');if(pause)pause.click();if(preset[2].scenario)document.querySelector('[data-scenario="'+preset[2].scenario+'"]').click();}Object.keys(preset[2]).forEach(function(id){if(id==='scenario')return;var input=document.getElementById(id);if(input){input.value=preset[2][id];input.dispatchEvent(new Event('input',{bubbles:true}));}});root.querySelectorAll('[data-lab-preset]').forEach(function(b){b.classList.toggle('on',b===button);b.setAttribute('aria-pressed',String(b===button));});document.getElementById('guided-instruction').textContent='正在观察：'+preset[0]+'。'+preset[1]+'。下方图表、指标和模型依据已重新计算。';compare();});});
  root.querySelector('#save-lab-baseline').addEventListener('click',function(){saved={metrics:measure(),inputs:Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})};this.textContent='更新方案 A';document.getElementById('clear-lab-baseline').hidden=false;document.getElementById('guided-instruction').textContent='已保存方案 A。现在选择另一工况或调整参数，观察 B 的变化。';compare();});
  root.querySelector('#clear-lab-baseline').addEventListener('click',function(){saved=null;document.getElementById('lab-comparison').hidden=true;this.hidden=true;document.getElementById('save-lab-baseline').textContent='保存当前为方案 A';});
  document.addEventListener('input',function(e){if(e.target.matches('input[type=range]'))requestAnimationFrame(compare);});
  window.LabCompare={refresh:compare};
})();
/* final-lab-interactions:end */


/* ai-proof:start */
(function(){
  'use strict';var NS='http://www.w3.org/2000/svg',current=null,mode='calculation';
  function el(tag,attrs,parent,text){var n=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;parent.appendChild(n);return n;}
  function draw(){if(!current)return;var c=current,s=document.getElementById('ai-proof-chart');if(!s)return;s.textContent='';var narrow=innerWidth<620,W=narrow?360:Math.max(460,Math.min(760,s.getBoundingClientRect().width||760));s.setAttribute('viewBox','0 0 '+W+' 252');
    var left=narrow?112:176,right=W-72,top=40,height=160;
    document.getElementById('ai-proof-live').textContent=c.detail;
    document.getElementById('ai-proof-caption').textContent=mode==='comparison'?c.comparisonNote:c.note;
    if(mode==='calculation'&&c.points){
      left=44;right=W-35;var colors=['#2e8064','#b08a3e','#b66647'];
      [0,.5,1].forEach(function(v){var x=left+v*(right-left),y=top+(1-v)*height;el('path',{d:'M'+x+' '+top+'V'+(top+height)+'M'+left+' '+y+'H'+right,stroke:'#e1e8dd',fill:'none'},s);el('text',{x:x,y:top+height+18,'text-anchor':'middle',fill:'#7d8e7c','font-size':10},s,v);});
      c.points.forEach(function(p){el('circle',{cx:left+p.x*(right-left),cy:top+(1-p.y)*height,r:2.5,fill:colors[p.cls],opacity:.65},s);});
      c.centers.forEach(function(p,i){var x=left+p[0]*(right-left),y=top+(1-p[1])*height;el('line',{x1:left+c.selected[0]*(right-left),y1:top+(1-c.selected[1])*height,x2:x,y2:y,stroke:colors[i],'stroke-dasharray':'4 4'},s);el('path',{d:'M'+(x-5)+' '+y+'h10M'+x+' '+(y-5)+'v10',stroke:colors[i],'stroke-width':3},s);});
      el('circle',{cx:left+c.selected[0]*(right-left),cy:top+(1-c.selected[1])*height,r:6,fill:'#183f2d',stroke:'#fff','stroke-width':2},s);el('text',{x:W/2,y:245,'text-anchor':'middle',fill:'#607b63','font-size':10},s,'横轴：CBL 归一化特征 · 纵轴：VDL 特征 · 十字：训练中心');
    }else{
      var bars=mode==='comparison'?c.comparison:c.bars;var max=c.fixedMax||Math.max.apply(null,bars.map(function(b){return Math.abs(b.value);}).concat([.001]));var rowH=Math.min(37,180/bars.length);
      bars.forEach(function(b,i){var y=top+i*rowH,bar=Math.min(1,Math.abs(b.value)/max)*(right-left);el('text',{x:left-10,y:y+11,'text-anchor':'end',fill:'#62775f','font-size':narrow?10:11},s,b.label);el('rect',{x:left,y:y,width:right-left,height:15,rx:2,fill:'#edf1e7'},s);el('rect',{x:left,y:y,width:Math.max(.5,bar),height:15,rx:2,fill:b.value<0?'#b37450':i===0&&mode==='comparison'?'#98a78c':'#3c8060'},s);el('text',{x:right+8,y:y+12,fill:'#3f6749','font-size':11},s,(b.value<0?'−':'')+Math.abs(b.value).toFixed(c.digits==null?2:c.digits)+(c.unit||''));});
      el('text',{x:left,y:235,fill:'#8a987f','font-size':10},s,mode==='comparison'?'同一组对照条件 · '+(c.comparisonUnit||''):c.axis||'柱长表示该项数值大小；符号见右侧');
    }
  }
  window.AIProof={update:function(c){current=c;draw();if(window.LabCompare)requestAnimationFrame(window.LabCompare.refresh);}};
  document.addEventListener('click',function(e){var b=e.target.closest('[data-proof-mode]');if(!b)return;mode=b.dataset.proofMode;document.querySelectorAll('[data-proof-mode]').forEach(function(n){var on=n===b;n.classList.toggle('on',on);n.setAttribute('aria-pressed',String(on));});draw();});
  window.addEventListener('resize',draw);
})();
/* ai-proof:end */

(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var DEPTH = 300;
  var STEP = 4;
  var CLEARANCE_MM = 38;
  var SUPPORT_REACH = 27;
  var COST = 2.4;
  var controls = {
    eccentricity: document.getElementById('eccentricity'),
    target: document.getElementById('target'),
    count: document.getElementById('max-centralizers'),
    depth: document.getElementById('depth')
  };
  var out = {
    eccentricity: document.getElementById('ecc-value'),
    target: document.getElementById('target-value'),
    count: document.getElementById('count-value'),
    depth: document.getElementById('depth-value'),
    minBefore: document.getElementById('min-before'),
    minAfter: document.getElementById('min-after'),
    coverageBefore: document.getElementById('coverage-before'),
    coverageAfter: document.getElementById('coverage-after'),
    usedCount: document.getElementById('used-count'),
    local: document.getElementById('local-standoff'),
    offset: document.getElementById('offset-value'),
    gap: document.getElementById('gap-value'),
    sectionNote: document.getElementById('section-note')
  };
  var chart = document.getElementById('profile-chart');
  var cross = document.getElementById('cross-section');
  var state = { base: [], optimized: [], placements: [], target: 60, selectedDepth: 150 };

  function svg(tag, attrs, parent, text) {
    var node = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    if (text != null) node.textContent = text;
    if (parent) parent.appendChild(node);
    return node;
  }

  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function pct(value) { return Math.round(value) + '%'; }
  function pointCount() { return Math.round(DEPTH / STEP) + 1; }

  function baseAt(depth, trend) {
    var z = depth;
    var undulation = 0.105 * Math.sin(z / 32) + 0.075 * Math.sin(z / 11 + 0.9) + 0.05 * Math.cos(z / 57 + 0.4);
    var localBulge = (z > 92 && z < 132 ? 0.075 : 0) + (z > 214 && z < 248 ? 0.06 : 0);
    return clamp(trend + undulation + localBulge, 0.04, 0.88);
  }

  function profileWith(placements, trend) {
    var result = [];
    for (var i = 0; i < pointCount(); i++) {
      var depth = i * STEP;
      var eccentricity = baseAt(depth, trend);
      var nearest = Infinity;
      placements.forEach(function (at) { nearest = Math.min(nearest, Math.abs(depth - at)); });
      var support = placements.length ? 0.76 * Math.exp(-nearest / SUPPORT_REACH) : 0;
      var effectiveEccentricity = clamp(eccentricity * (1 - support), 0.025, 0.95);
      result.push({ depth: depth, eccentricity: eccentricity, ratio: 1 - effectiveEccentricity });
    }
    return result;
  }

  function coverage(profile, target) {
    var hits = profile.reduce(function (sum, p) { return sum + (p.ratio * 100 >= target ? 1 : 0); }, 0);
    return hits / profile.length;
  }

  function optimize(trend, target, maxCount) {
    var chosen = [];
    var current = profileWith(chosen, trend);
    var currentObjective = coverage(current, target) * 100;
    var candidates = [];
    for (var z = 14; z <= DEPTH - 14; z += 20) candidates.push(z);

    while (chosen.length < maxCount) {
      var best = null;
      var bestGain = 0;
      candidates.forEach(function (candidate) {
        if (chosen.some(function (at) { return Math.abs(at - candidate) < 24; })) return;
        var nextPositions = chosen.concat([candidate]);
        var nextProfile = profileWith(nextPositions, trend);
        var objective = coverage(nextProfile, target) * 100 - COST * nextPositions.length;
        var gain = objective - currentObjective;
        if (gain > bestGain) {
          bestGain = gain;
          best = { at: candidate, profile: nextProfile, objective: objective };
        }
      });
      if (!best) break;
      chosen.push(best.at);
      current = best.profile;
      currentObjective = best.objective;
    }
    return { placements: chosen.sort(function (a, b) { return a - b; }), profile: current };
  }

  function selectedPoint() {
    var index = clamp(Math.round(state.selectedDepth / STEP), 0, state.base.length - 1);
    return { base: state.base[index], optimized: state.optimized[index] };
  }

  function meanMinimum(profile) {
    return profile.reduce(function (minimum, p) { return Math.min(minimum, p.ratio); }, 1);
  }

  function renderChart() {
    chart.textContent = '';
    var narrow = window.innerWidth <= 660;
    var chartWidth = narrow ? 400 : 820;
    var left = narrow ? 88 : 120, top = 30, width = narrow ? 300 : 650, height = 310;
    chart.setAttribute('viewBox', '0 0 ' + chartWidth + ' 416');
    var x = function (value) { return left + value * width; };
    var y = function (depth) { return top + depth / DEPTH * height; };
    var styles = {
      text: '#73827c', grid: '#e8eeea', jade: '#2d7968', clay: '#c46b43',
      pale: '#f5f8f6', target: '#83938c', ink: '#31443e'
    };

    svg('rect', { x: left, y: top, width: width, height: height, fill: '#fff' }, chart);
    for (var tick = 0; tick <= 100; tick += 20) {
      var xx = x(tick / 100);
      svg('line', { x1: xx, x2: xx, y1: top, y2: top + height, stroke: styles.grid, 'stroke-width': 1 }, chart);
      svg('text', { x: xx, y: 16, 'text-anchor': 'middle', fill: styles.text, 'font-size': 10, 'font-family': 'sans-serif' }, chart, tick + '%');
    }
    for (var d = 0; d <= DEPTH; d += 50) {
      var yy = y(d);
      svg('line', { x1: left, x2: left + width, y1: yy, y2: yy, stroke: styles.grid, 'stroke-width': 1 }, chart);
      svg('text', { x: left - 13, y: yy + 3.5, 'text-anchor': 'end', fill: styles.text, 'font-size': 10, 'font-family': 'sans-serif' }, chart, d + ' m');
    }
    svg('text', { x: left + width / 2, y: 405, 'text-anchor': 'middle', fill: styles.text, 'font-size': 10, 'font-family': 'sans-serif' }, chart, '简化几何居中度');
    svg('text', { x: 17, y: top + height / 2, transform: 'rotate(-90 17 ' + (top + height / 2) + ')', 'text-anchor': 'middle', fill: styles.text, 'font-size': 10, 'font-family': 'sans-serif' }, chart, '测深');

    var targetX = x(state.target / 100);
    svg('line', { x1: targetX, x2: targetX, y1: top, y2: top + height, stroke: styles.target, 'stroke-width': 1.4, 'stroke-dasharray': '5 5' }, chart);
    svg('text', { x: targetX + 5, y: top + 13, fill: styles.target, 'font-size': 9, 'font-family': 'sans-serif' }, chart, '目标 ' + state.target + '%');

    var trackX = narrow ? 32 : 56;
    state.placements.forEach(function (at) {
      var cy = y(at);
      svg('path', { d: 'M' + trackX + ' ' + (cy - 5) + 'l5 5-5 5-5-5z', fill: styles.jade, stroke: '#fff', 'stroke-width': 1 }, chart);
      svg('line', { x1: trackX + 9, x2: left - 4, y1: cy, y2: cy, stroke: styles.jade, 'stroke-width': 1, 'stroke-opacity': 0.25 }, chart);
    });
    svg('text', { x: trackX, y: 18, 'text-anchor': 'middle', fill: styles.text, 'font-size': 8, 'font-family': 'sans-serif' }, chart, '扶正器');

    function pathFor(key) {
      return state[key].map(function (p, i) {
        return (i ? 'L' : 'M') + x(p.ratio).toFixed(1) + ' ' + y(p.depth).toFixed(1);
      }).join(' ');
    }
    svg('path', { d: pathFor('base'), fill: 'none', stroke: styles.clay, 'stroke-width': 2, 'stroke-dasharray': '5 4', 'stroke-linejoin': 'round', 'stroke-linecap': 'round', opacity: 0.9 }, chart);
    svg('path', { d: pathFor('optimized'), fill: 'none', stroke: styles.jade, 'stroke-width': 2.8, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, chart);

    var selectedY = y(state.selectedDepth);
    svg('line', { x1: left, x2: left + width, y1: selectedY, y2: selectedY, stroke: styles.ink, 'stroke-width': 1, 'stroke-dasharray': '2 4', opacity: 0.75 }, chart);
    var point = selectedPoint();
    svg('circle', { cx: x(point.base.ratio), cy: selectedY, r: 4, fill: '#fff', stroke: styles.clay, 'stroke-width': 2 }, chart);
    svg('circle', { cx: x(point.optimized.ratio), cy: selectedY, r: 4.5, fill: styles.jade, stroke: '#fff', 'stroke-width': 1.5 }, chart);

    svg('rect', { x: left, y: top, width: width, height: height, fill: 'transparent', 'pointer-events': 'all', cursor: 'crosshair' }, chart);
  }

  function chooseDepth(event) {
    var rect = chart.getBoundingClientRect();
    var viewY = (event.clientY - rect.top) * 416 / rect.height;
    var top = 30, height = 310;
    if (viewY < top || viewY > top + height) return;
    state.selectedDepth = clamp(Math.round(((viewY - top) / height * DEPTH) / STEP) * STEP, 0, DEPTH);
    controls.depth.value = state.selectedDepth;
    renderDepthDetail();
    renderChart();
  }

  chart.addEventListener('pointerdown', function (event) {
    chart.setPointerCapture(event.pointerId);
    chart.dataset.scrubbing = 'true';
    chooseDepth(event);
  });
  chart.addEventListener('pointermove', function (event) {
    if (chart.dataset.scrubbing === 'true') chooseDepth(event);
  });
  chart.addEventListener('pointerup', function () { delete chart.dataset.scrubbing; });
  chart.addEventListener('pointercancel', function () { delete chart.dataset.scrubbing; });

  function renderCrossSection(base, optimized) {
    cross.textContent = '';
    cross.setAttribute('viewBox', '0 0 320 275');
    var cx = 138, cy = 113, hole = 76, casing = 43;
    var clearancePx = hole - casing;
    var offsetPx = (1 - optimized.ratio) * clearancePx;
    var casingX = cx + offsetPx;
    var color = optimized.ratio * 100 >= state.target ? '#2d7968' : '#c46b43';

    svg('circle', { cx: cx, cy: cy, r: hole, fill: '#e8f0ed', stroke: '#709087', 'stroke-width': 2 }, cross);
    svg('text', { x: cx, y: cy - hole - 10, 'text-anchor': 'middle', fill: '#62736c', 'font-size': 10, 'font-family': 'sans-serif' }, cross, '井眼边界');
    svg('circle', { cx: cx, cy: cy, r: 2.5, fill: '#527368' }, cross);
    svg('line', { x1: cx - 8, x2: cx + 8, y1: cy, y2: cy, stroke: '#527368', 'stroke-width': 1, opacity: 0.6 }, cross);
    svg('line', { x1: cx, x2: cx, y1: cy - 8, y2: cy + 8, stroke: '#527368', 'stroke-width': 1, opacity: 0.6 }, cross);
    svg('circle', { cx: casingX, cy: cy, r: casing, fill: '#fff', stroke: '#193b32', 'stroke-width': 2 }, cross);
    svg('circle', { cx: casingX, cy: cy, r: 2.5, fill: color }, cross);

    var narrowStart = casingX + casing;
    var narrowEnd = cx + hole - 4;
    svg('line', { x1: narrowStart, x2: narrowEnd, y1: cy, y2: cy, stroke: color, 'stroke-width': 2.2 }, cross);
    svg('line', { x1: cx, x2: casingX, y1: cy + 10, y2: cy + 10, stroke: '#c46b43', 'stroke-width': 1.3, 'stroke-dasharray': '3 3' }, cross);
    svg('text', { x: 160, y: 216, 'text-anchor': 'middle', fill: '#62736c', 'font-size': 11, 'font-family': 'sans-serif' }, cross, '井眼 φ216 mm · 套管 φ140 mm');
    svg('text', { x: 160, y: 233, 'text-anchor': 'middle', fill: '#62736c', 'font-size': 10, 'font-family': 'sans-serif' }, cross, '几何教学示意');
    svg('circle', { cx: 30, cy: 254, r: 5, fill: '#e8f0ed', stroke: '#709087', 'stroke-width': 1.5 }, cross);
    svg('text', { x: 41, y: 258, fill: '#62736c', 'font-size': 11, 'font-family': 'sans-serif' }, cross, '井壁');
    svg('circle', { cx: 105, cy: 254, r: 5, fill: '#fff', stroke: '#193b32', 'stroke-width': 1.5 }, cross);
    svg('text', { x: 116, y: 258, fill: '#62736c', 'font-size': 11, 'font-family': 'sans-serif' }, cross, '套管');
    svg('circle', { cx: 180, cy: 254, r: 5, fill: color }, cross);
    svg('text', { x: 191, y: 258, fill: '#62736c', 'font-size': 11, 'font-family': 'sans-serif' }, cross, '搜索后中心');

    var gapMm = Math.max(0, CLEARANCE_MM * optimized.ratio);
    var offsetMm = CLEARANCE_MM * (1 - optimized.ratio);
    out.local.textContent = pct(optimized.ratio * 100);
    out.local.style.color = color;
    out.offset.textContent = offsetMm.toFixed(1) + ' mm';
    out.gap.textContent = gapMm.toFixed(1) + ' mm';
    if (Math.abs(base.depth - state.selectedDepth) < STEP / 2 && state.placements.some(function (p) { return Math.abs(p - state.selectedDepth) < 10; })) {
      out.sectionNote.textContent = '此处靠近搜索建议的扶正器位置；图中间隙为教学公式估算。';
    } else if (optimized.ratio * 100 < state.target) {
      out.sectionNote.textContent = '当前点低于所设目标；可增加布置上限，观察搜索能否改善覆盖率。';
    } else {
      out.sectionNote.textContent = '当前点达到所设目标。灰绿色表示井眼截面，白色圆形表示套管。';
    }
  }

  function renderDepthDetail() {
    var pair = selectedPoint();
    out.depth.textContent = state.selectedDepth + ' m';
    renderCrossSection(pair.base, pair.optimized);
  }

  function recompute() {
    var trend = Number(controls.eccentricity.value) / 100;
    state.target = Number(controls.target.value);
    state.selectedDepth = Number(controls.depth.value);
    var result = optimize(trend, state.target, Number(controls.count.value));
    state.base = profileWith([], trend);
    state.optimized = result.profile;
    state.placements = result.placements;

    out.eccentricity.textContent = Math.round(trend * 100) + '%';
    out.target.textContent = state.target + '%';
    out.count.textContent = controls.count.value + ' 个';
    out.minBefore.textContent = pct(meanMinimum(state.base) * 100);
    out.minAfter.textContent = pct(meanMinimum(state.optimized) * 100);
    out.coverageBefore.textContent = pct(coverage(state.base, state.target) * 100);
    out.coverageAfter.textContent = pct(coverage(state.optimized, state.target) * 100);
    out.usedCount.textContent = String(state.placements.length);
    renderChart();
    renderDepthDetail();
    var uniform=state.placements.map(function(_,i){return DEPTH*(i+1)/(state.placements.length+1);});var uniformProfile=profileWith(uniform,trend);
 window.AIProof.update({bars:[{label:'未布置',value:coverage(state.base,state.target)*100}].concat(state.placements.map(function(_,i){return {label:'搜索位置前 '+(i+1)+' 个',value:coverage(profileWith(state.placements.slice(0,i+1),trend),state.target)*100};})),detail:'候选搜索在最小间距 24 m 下选择位置。当前共 '+state.placements.length+' 个，建议深度 '+(state.placements.join('、')||'无')+' m；每个位置都按覆盖收益减去数量代价比较。',note:'为便于读井深，这里按深度排序累计位置，不代表贪心选择的原始先后顺序。',comparison:[{label:'同数量均匀布置',value:coverage(uniformProfile,state.target)*100},{label:'贪心搜索布局',value:coverage(state.optimized,state.target)*100}],unit:'%',digits:1,comparisonUnit:'同数量、同几何条件下的目标覆盖率',comparisonNote:'均匀布置为简单基线；两者均用相同简化支撑模型计算，局部搜索未必优于所有布局。'});
  }

  [controls.eccentricity, controls.target, controls.count].forEach(function (input) {
    input.addEventListener('input', recompute);
  });
  controls.depth.addEventListener('input', function () {
    state.selectedDepth = Number(controls.depth.value);
    renderDepthDetail();
    renderChart();
  });
  document.getElementById('reset').addEventListener('click', function () {
    controls.eccentricity.value = 42;
    controls.target.value = 60;
    controls.count.value = 5;
    controls.depth.value = 150;
    recompute();
  });

  var resizeFrame = null;
  window.addEventListener('resize', function () {
    if (resizeFrame !== null) cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(function () { resizeFrame = null; renderChart(); });
  });
  recompute();
}());

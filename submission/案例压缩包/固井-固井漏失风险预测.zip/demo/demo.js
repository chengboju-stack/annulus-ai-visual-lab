/* final-lab-interactions:start */
(function(){
  'use strict';
  var configs={
    c1:{metrics:[['selected-class','候选类别'],['selected-confidence','相似度置信分'],['review-share','复核比例']],presets:[['良好响应','低振幅与较弱套管波特征',{depth:24,confidence:72}],['过渡区间','检查靠近分类边界的位置',{depth:72,confidence:92}],['较差响应','比较较强套管波特征',{depth:112,confidence:72}]]},
    c2:{metrics:[['current-efficiency','当前预测效率'],['best-efficiency','候选最高效率'],['frac-margin','破裂压力余量']],presets:[['保守方案','较低排量与适中密度',{density:1400,rate:8,centralization:70}],['高排量试探','检查效率改善是否触及压力约束',{density:1640,rate:20,centralization:70}],['改善居中度','固定密度排量，只改变几何条件',{density:1500,rate:13,centralization:95}]]},
    c3:{metrics:[['risk-probability','模型风险分数'],['risk-level','当前风险提示'],['recall-score','留出样本召回率']],presets:[['宽窗口','余量充足，邻井历史频率低',{'window-width':75,'ecd-margin':24,'history-rate':0,'decision-threshold':45}],['窄窗口','多因素叠加，观察贡献变化',{'window-width':25,'ecd-margin':3,'history-rate':45,'decision-threshold':45}],['提高阈值','固定井况，区分分数与决策',{'window-width':42,'ecd-margin':10,'history-rate':18,'decision-threshold':70}]]},
    c4:{metrics:[['min-after','方案最小居中度'],['coverage-after','目标覆盖率'],['used-count','扶正器数量']],presets:[['无扶正器','建立原始几何对照',{eccentricity:55,target:65,'max-centralizers':0,depth:120}],['布置五个','在数量约束下搜索薄弱段',{eccentricity:55,target:65,'max-centralizers':5,depth:120}],['增加上限','观察新增位置是否仍有收益',{eccentricity:55,target:65,'max-centralizers':8,depth:120}]]},
    d2:{metrics:[['anomaly-score','异常分数'],['persistence','超限持续窗'],['top-channel','贡献最大通道']],presets:[['正常留出窗','正常工况下也应检查误报',{scenario:'normal','time-index':100,threshold:62}],['井漏前兆','让多个通道共同参与判断',{scenario:'loss','time-index':100,threshold:62}],['降低阈值','相同早期时刻，调整决策灵敏度',{scenario:'loss','time-index':80,threshold:35}]]}
  };
  var scene=document.querySelector('main').dataset.scene,config=configs[scene];if(!config)return;
  var root=document.getElementById('lab-interactions');if(!root)return;
  root.innerHTML='<div class="guided-top"><div><span>EXPERIMENT / 自己动手验证</span><h2>先选工况，再保存一组对照。</h2></div><span class="guided-index">'+(scene==='d2'?'拓展实验':'固井实验')+'</span></div><div class="guided-presets">'+config.presets.map(function(p,i){return '<button type="button" data-lab-preset="'+i+'" aria-pressed="false"><b>0'+(i+1)+'</b><span>'+p[0]+'<small>'+p[1]+'</small></span><i>↗</i></button>';}).join('')+'</div><div class="comparison-tools"><p id="guided-instruction">点击一种典型工况；保存为 A 后，调整下方参数查看 A / B 对比。</p><button type="button" id="save-lab-baseline">保存当前为方案 A</button><button type="button" id="clear-lab-baseline" hidden>清除对照</button></div><div id="lab-comparison" hidden aria-live="polite"></div>';
  var saved=null;
  function measure(){return config.metrics.map(function(m){var node=document.getElementById(m[0]);return {label:m[1],text:node?node.textContent.trim():'—'};});}
  function safe(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function conditionText(inputs){var names={confidence:'最低置信 %',depth:'测深 m',density:'密度 kg/m³',rate:'排量 L/s',centralization:'居中度 %','window-width':'窗口宽度 ×0.01 g/cm³','ecd-margin':'ECD 余量 ×0.01 g/cm³','history-rate':'历史频率 %','decision-threshold':'预警阈值 %',eccentricity:'偏心 %',target:'目标 %','max-centralizers':'数量上限',threshold:'阈值 %','time-index':'时间窗索引'};return inputs.map(function(x){return (names[x.id]||x.id)+' '+x.value;}).join(' · ');}
  function compare(){if(!saved)return;var now=measure(),out=document.getElementById('lab-comparison');out.hidden=false;out.innerHTML='<div class="compare-intro"><span>方案 A · 保存时的输入</span><span>方案 B · 当前输入</span></div>'+now.map(function(m,i){var a=saved.metrics[i].text,b=m.text,an=parseFloat(a),bn=parseFloat(b),valid=Number.isFinite(an)&&Number.isFinite(bn),max=valid?Math.max(Math.abs(an),Math.abs(bn),1):1;return '<div class="compare-row"><b>'+m.label+'</b><div><span>'+safe(a)+'</span>'+(valid?'<i class="compare-bar a" style="width:'+Math.max(1,Math.abs(an)/max*100)+'%"></i>':'')+'</div><div><span>'+safe(b)+'</span>'+(valid?'<i class="compare-bar b" style="width:'+Math.max(1,Math.abs(bn)/max*100)+'%"></i>':'')+'</div><small>'+(a===b?'相同':valid?'变化 '+(bn-an>=0?'+':'')+(bn-an).toFixed(2):'结果变化')+'</small></div>';}).join('')+'<div class="compare-conditions"><p><b>A 条件：</b>'+safe(conditionText(saved.inputs))+'</p><p><b>B 条件：</b>'+safe(conditionText(Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})))+'</p></div><p class="comparison-boundary">对比当前演示的实际显示结果；数值变化不自动代表工程更优。概率 / 分数、余量、覆盖率需结合方法边界分别解释。</p>';}
  root.querySelectorAll('[data-lab-preset]').forEach(function(button){button.addEventListener('click',function(){var preset=config.presets[Number(button.dataset.labPreset)];if(scene==='d2'){var pause=document.getElementById('pause');if(pause)pause.click();if(preset[2].scenario)document.querySelector('[data-scenario="'+preset[2].scenario+'"]').click();}Object.keys(preset[2]).forEach(function(id){if(id==='scenario')return;var input=document.getElementById(id);if(input){input.value=preset[2][id];input.dispatchEvent(new Event('input',{bubbles:true}));}});root.querySelectorAll('[data-lab-preset]').forEach(function(b){b.classList.toggle('on',b===button);b.setAttribute('aria-pressed',String(b===button));});document.getElementById('guided-instruction').textContent='正在观察：'+preset[0]+'。'+preset[1]+'。下方图表、指标和模型依据已重新计算。';compare();});});
  root.querySelector('#save-lab-baseline').addEventListener('click',function(){saved={metrics:measure(),inputs:Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})};this.textContent='更新方案 A';document.getElementById('clear-lab-baseline').hidden=false;document.getElementById('guided-instruction').textContent='已保存方案 A。现在选择另一工况或调整参数，观察 B 的变化。';compare();});
  root.querySelector('#clear-lab-baseline').addEventListener('click',function(){saved=null;document.getElementById('lab-comparison').hidden=true;this.hidden=true;document.getElementById('save-lab-baseline').textContent='保存当前为方案 A';});
  document.addEventListener('input',function(e){if(e.target.matches('input[type=range]'))requestAnimationFrame(compare);});
  window.LabCompare={refresh:compare};
})();
/* final-lab-interactions:end */


/* ai-proof:start */
(function(){
  'use strict';var NS='http://www.w3.org/2000/svg',current=null,mode='calculation';
  function el(tag,attrs,parent,text){var n=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;parent.appendChild(n);return n;}
  function draw(){if(!current)return;var c=current,s=document.getElementById('ai-proof-chart');if(!s)return;s.textContent='';var narrow=innerWidth<620,W=narrow?360:Math.max(460,Math.min(760,s.getBoundingClientRect().width||760));s.setAttribute('viewBox','0 0 '+W+' 252');
    var left=narrow?112:176,right=W-72,top=40,height=160;
    document.getElementById('ai-proof-live').textContent=c.detail;
    document.getElementById('ai-proof-caption').textContent=mode==='comparison'?c.comparisonNote:c.note;
    if(mode==='calculation'&&c.points){
      left=44;right=W-35;var colors=['#2e8064','#b08a3e','#b66647'];
      [0,.5,1].forEach(function(v){var x=left+v*(right-left),y=top+(1-v)*height;el('path',{d:'M'+x+' '+top+'V'+(top+height)+'M'+left+' '+y+'H'+right,stroke:'#e1e8dd',fill:'none'},s);el('text',{x:x,y:top+height+18,'text-anchor':'middle',fill:'#7d8e7c','font-size':10},s,v);});
      c.points.forEach(function(p){el('circle',{cx:left+p.x*(right-left),cy:top+(1-p.y)*height,r:2.5,fill:colors[p.cls],opacity:.65},s);});
      c.centers.forEach(function(p,i){var x=left+p[0]*(right-left),y=top+(1-p[1])*height;el('line',{x1:left+c.selected[0]*(right-left),y1:top+(1-c.selected[1])*height,x2:x,y2:y,stroke:colors[i],'stroke-dasharray':'4 4'},s);el('path',{d:'M'+(x-5)+' '+y+'h10M'+x+' '+(y-5)+'v10',stroke:colors[i],'stroke-width':3},s);});
      el('circle',{cx:left+c.selected[0]*(right-left),cy:top+(1-c.selected[1])*height,r:6,fill:'#183f2d',stroke:'#fff','stroke-width':2},s);el('text',{x:W/2,y:245,'text-anchor':'middle',fill:'#607b63','font-size':10},s,'横轴：CBL 归一化特征 · 纵轴：VDL 特征 · 十字：训练中心');
    }else{
      var bars=mode==='comparison'?c.comparison:c.bars;var max=c.fixedMax||Math.max.apply(null,bars.map(function(b){return Math.abs(b.value);}).concat([.001]));var rowH=Math.min(37,180/bars.length);
      bars.forEach(function(b,i){var y=top+i*rowH,bar=Math.min(1,Math.abs(b.value)/max)*(right-left);el('text',{x:left-10,y:y+11,'text-anchor':'end',fill:'#62775f','font-size':narrow?10:11},s,b.label);el('rect',{x:left,y:y,width:right-left,height:15,rx:2,fill:'#edf1e7'},s);el('rect',{x:left,y:y,width:Math.max(.5,bar),height:15,rx:2,fill:b.value<0?'#b37450':i===0&&mode==='comparison'?'#98a78c':'#3c8060'},s);el('text',{x:right+8,y:y+12,fill:'#3f6749','font-size':11},s,(b.value<0?'−':'')+Math.abs(b.value).toFixed(c.digits==null?2:c.digits)+(c.unit||''));});
      el('text',{x:left,y:235,fill:'#8a987f','font-size':10},s,mode==='comparison'?'同一组对照条件 · '+(c.comparisonUnit||''):c.axis||'柱长表示该项数值大小；符号见右侧');
    }
  }
  window.AIProof={update:function(c){current=c;draw();if(window.LabCompare)requestAnimationFrame(window.LabCompare.refresh);}};
  document.addEventListener('click',function(e){var b=e.target.closest('[data-proof-mode]');if(!b)return;mode=b.dataset.proofMode;document.querySelectorAll('[data-proof-mode]').forEach(function(n){var on=n===b;n.classList.toggle('on',on);n.setAttribute('aria-pressed',String(on));});draw();});
  window.addEventListener('resize',draw);
})();
/* ai-proof:end */

(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var controls = {
    window: document.getElementById('window-width'),
    margin: document.getElementById('ecd-margin'),
    history: document.getElementById('history-rate'),
    threshold: document.getElementById('decision-threshold')
  };
  var out = {
    window: document.getElementById('window-output'),
    margin: document.getElementById('margin-output'),
    history: document.getElementById('history-output'),
    threshold: document.getElementById('threshold-output'),
    probability: document.getElementById('risk-probability'),
    level: document.getElementById('risk-level'),
    recommendation: document.getElementById('recommendation'),
    brier: document.getElementById('brier-score'),
    recall: document.getElementById('recall-score'),
    size: document.getElementById('test-size'),
    bar: document.getElementById('prob-bar'),
    thresholdMark: document.getElementById('threshold-mark'),
    card: document.getElementById('risk-card')
  };
  var pressureSvg = document.getElementById('pressure-chart');
  var curveSvg = document.getElementById('response-chart');
  var contributionSvg = document.getElementById('contribution-chart');
  var model;

  function svg(tag, attrs, parent, text) {
    var node = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    if (text != null) node.textContent = text;
    if (parent) parent.appendChild(node);
    return node;
  }
  function clamp(x, min, max) { return Math.max(min, Math.min(max, x)); }
  function sigmoid(x) { return 1 / (1 + Math.exp(-clamp(x, -24, 24))); }
  function rng(seed) {
    var s = seed >>> 0;
    return function () { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; };
  }
  function features(windowWidth, margin, history) {
    return [clamp((0.75 - windowWidth) / 0.5, 0, 1), clamp((0.24 - margin) / 0.21, 0, 1), clamp(history / 0.45, 0, 1)];
  }
  function probabilityFromSyntheticRule(x) {
    return sigmoid(-3.05 + 2.2 * x[0] + 2.55 * x[1] + 2.35 * x[2]);
  }
  function generateRows(count, random) {
    var rows = [];
    for (var i = 0; i < count; i++) {
      var w = 0.25 + random() * 0.5;
      var m = 0.03 + random() * 0.21;
      var h = random() * 0.45;
      var x = features(w, m, h);
      var p = probabilityFromSyntheticRule(x);
      rows.push({ x: x, y: random() < p ? 1 : 0 });
    }
    return rows;
  }
  function fit(rows) {
    var weights = [0, 0, 0];
    var bias = 0;
    var learningRate = 0.46;
    var epochs = 170;
    for (var epoch = 0; epoch < epochs; epoch++) {
      var grad = [0, 0, 0];
      var gradBias = 0;
      rows.forEach(function (row) {
        var z = bias + row.x.reduce(function (sum, x, i) { return sum + x * weights[i]; }, 0);
        var error = sigmoid(z) - row.y;
        gradBias += error;
        row.x.forEach(function (x, i) { grad[i] += error * x; });
      });
      var invN = 1 / rows.length;
      bias -= learningRate * gradBias * invN;
      weights = weights.map(function (weight, i) { return weight - learningRate * (grad[i] * invN + 0.012 * weight); });
    }
    return { weights: weights, bias: bias };
  }
  function predict(modelState, x) {
    return sigmoid(modelState.bias + x.reduce(function (sum, value, i) { return sum + value * modelState.weights[i]; }, 0));
  }
  function evaluate(rows, modelState, threshold) {
    var brier = 0, tp = 0, fn = 0;
    rows.forEach(function (row) {
      var p = predict(modelState, row.x);
      brier += (p - row.y) * (p - row.y);
      if (row.y) { if (p >= threshold) tp++; else fn++; }
    });
    return { brier: brier / rows.length, recall: tp + fn ? tp / (tp + fn) : 0 };
  }

  function fitModel() {
    var random = rng(20261028);
    var rows = generateRows(720, random);
    var train = rows.slice(0, 560);
    var test = rows.slice(560);
    return { model: fit(train), test: test, trainCount: train.length, prior: train.reduce(function(s,r){return s+r.y;},0)/train.length };
  }

  function renderPressure(windowWidth, margin) {
    pressureSvg.textContent = '';
    var min = 1.2, max = 2.4, top = 34, height = 207;
    var x0 = 108, barWidth = 70;
    var pore = 1.35;
    var frac = pore + windowWidth;
    var ecd = frac - margin;
    var y = function (value) { return top + height * (max - value) / (max - min); };
    svg('text', { x: 23, y: 20, fill: '#788780', 'font-size': 9, 'font-family': 'sans-serif' }, pressureSvg, '等效密度');
    svg('rect', { x: x0, y: top, width: barWidth, height: y(frac) - top, fill: '#f5e8df' }, pressureSvg);
    svg('rect', { x: x0, y: y(frac), width: barWidth, height: y(pore) - y(frac), fill: '#e3efea' }, pressureSvg);
    svg('rect', { x: x0, y: y(pore), width: barWidth, height: top + height - y(pore), fill: '#e8eff2' }, pressureSvg);
    svg('rect', { x: x0, y: top, width: barWidth, height: height, fill: 'none', stroke: '#aab8b1', 'stroke-width': 1 }, pressureSvg);
    for (var tick = 1.2; tick <= 2.4001; tick += 0.2) {
      var yy = y(tick);
      svg('line', { x1: x0 - 5, x2: x0 + barWidth + 4, y1: yy, y2: yy, stroke: '#fff', 'stroke-width': 1 }, pressureSvg);
      svg('text', { x: x0 - 12, y: yy + 3, 'text-anchor': 'end', fill: '#7c8a84', 'font-size': 9, 'font-family': 'sans-serif' }, pressureSvg, tick.toFixed(1));
    }
    function rule(value, color, label, width) {
      var yy = y(value);
      svg('line', { x1: x0 - 7, x2: x0 + barWidth + 12, y1: yy, y2: yy, stroke: color, 'stroke-width': width }, pressureSvg);
      svg('text', { x: 200, y: yy + 3, fill: color, 'font-size': 10, 'font-family': 'sans-serif' }, pressureSvg, label + '  ' + value.toFixed(2));
    }
    rule(frac, '#b75e39', '破裂上限', 2);
    rule(pore, '#5d7d89', '孔隙压力', 2);
    rule(ecd, '#26745f', '当前 ECD', 3);
    svg('path', { d: 'M' + (x0 + barWidth + 17) + ' ' + y(ecd) + 'h10m-4-4 4 4-4 4', fill: 'none', stroke: '#26745f', 'stroke-width': 1.5 }, pressureSvg);
    svg('text', { x: 200, y: 263, fill: '#697a74', 'font-size': 10, 'font-family': 'sans-serif' }, pressureSvg, '窗口 ' + windowWidth.toFixed(2) + ' · ECD 余量 ' + margin.toFixed(2) + ' g/cm³');
  }

  function renderCurve(windowWidth, margin, history) {
    curveSvg.textContent = '';
    var narrow = window.innerWidth <= 620;
    var chartWidth = narrow ? 390 : 510;
    var left = narrow ? 46 : 58, top = 29, width = narrow ? 320 : 420, height = 209;
    curveSvg.setAttribute('viewBox', '0 0 ' + chartWidth + ' 286');
    var x = function (v) { return left + (v - 0.25) / 0.5 * width; };
    var y = function (p) { return top + (1 - p) * height; };
    for (var v = 0; v <= 1.0001; v += 0.25) {
      var yy = y(v);
      svg('line', { x1: left, x2: left + width, y1: yy, y2: yy, stroke: '#e8eeea', 'stroke-width': 1 }, curveSvg);
      svg('text', { x: left - 10, y: yy + 3, 'text-anchor': 'end', fill: '#7c8a84', 'font-size': 9, 'font-family': 'sans-serif' }, curveSvg, Math.round(v * 100) + '%');
    }
    for (var w = 0.25; w <= 0.7501; w += 0.1) {
      var xx = x(w);
      svg('line', { x1: xx, x2: xx, y1: top, y2: top + height, stroke: '#edf1ee', 'stroke-width': 1 }, curveSvg);
      svg('text', { x: xx, y: top + height + 19, 'text-anchor': 'middle', fill: '#7c8a84', 'font-size': 9, 'font-family': 'sans-serif' }, curveSvg, w.toFixed(2));
    }
    var points = [];
    for (var i = 0; i <= 50; i++) {
      var testW = 0.25 + i / 50 * 0.5;
      var p = predict(model.model, features(testW, margin, history));
      points.push((i ? 'L' : 'M') + x(testW).toFixed(1) + ' ' + y(p).toFixed(1));
    }
    var current = predict(model.model, features(windowWidth, margin, history));
    svg('path', { d: points.join(' '), fill: 'none', stroke: '#2d7968', 'stroke-width': 2.5, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, curveSvg);
    svg('line', { x1: x(windowWidth), x2: x(windowWidth), y1: top, y2: top + height, stroke: '#bd6841', 'stroke-width': 1.5, 'stroke-dasharray': '4 4' }, curveSvg);
    svg('circle', { cx: x(windowWidth), cy: y(current), r: 5, fill: '#bd6841', stroke: '#fff', 'stroke-width': 2 }, curveSvg);
    svg('text', { x: left + width / 2, y: 281, 'text-anchor': 'middle', fill: '#697a74', 'font-size': 10, 'font-family': 'sans-serif' }, curveSvg, '压力窗口宽度 / g·cm⁻³');
  }

  function renderContributions(x) {
    contributionSvg.textContent = '';
    var narrow = window.innerWidth <= 620;
    if (narrow) contributionSvg.setAttribute('viewBox', '0 0 400 230');
    else contributionSvg.setAttribute('viewBox', '0 0 920 184');
    var names = ['窗口偏窄', 'ECD 余量较小', '邻井历史漏失频率'];
    var colors = ['#6b8d98', '#c46b43', '#a6813b'];
    var left = narrow ? 12 : 184, top = narrow ? 13 : 37, maxWidth = narrow ? 310 : 570, rowGap = narrow ? 65 : 43;
    var maxValue = Math.max(0.6, model.model.weights.reduce(function (max, weight, i) { return Math.max(max, Math.abs(weight * x[i])); }, 0));
    if (!narrow) svg('line', { x1: left, x2: left + maxWidth, y1: 23, y2: 23, stroke: '#e5ebe7', 'stroke-width': 1 }, contributionSvg);
    for (var i = 0; i < 3; i++) {
      var value = model.model.weights[i] * x[i];
      var barWidth = Math.abs(value) / maxValue * maxWidth;
      var yy = top + i * rowGap;
      if (narrow) {
        svg('text', { x: left, y: yy + 9, fill: '#566760', 'font-size': 10, 'font-family': 'sans-serif' }, contributionSvg, names[i]);
        svg('rect', { x: left, y: yy + 15, width: maxWidth, height: 13, fill: '#f1f4f2' }, contributionSvg);
        svg('rect', { x: value >= 0 ? left : left - barWidth, y: yy + 15, width: barWidth, height: 13, fill: colors[i], opacity: 0.84 }, contributionSvg);
        svg('text', { x: left + maxWidth + 7, y: yy + 25, fill: colors[i], 'font-size': 9, 'font-family': 'sans-serif' }, contributionSvg, (value >= 0 ? '+' : '') + value.toFixed(2));
      } else {
        svg('text', { x: left - 13, y: yy + 12, 'text-anchor': 'end', fill: '#566760', 'font-size': 10, 'font-family': 'sans-serif' }, contributionSvg, names[i]);
        svg('rect', { x: left, y: yy, width: maxWidth, height: 17, fill: '#f1f4f2' }, contributionSvg);
        svg('rect', { x: value >= 0 ? left : left - barWidth, y: yy, width: barWidth, height: 17, fill: colors[i], opacity: 0.84 }, contributionSvg);
        svg('text', { x: left + maxWidth + 12, y: yy + 12, fill: colors[i], 'font-size': 10, 'font-family': 'sans-serif' }, contributionSvg, (value >= 0 ? '+' : '') + value.toFixed(2));
      }
    }
    var bias = model.model.bias;
    svg('text', { x: narrow ? 12 : 184, y: narrow ? 222 : 174, fill: '#788780', 'font-size': 9, 'font-family': 'sans-serif' }, contributionSvg, '模型截距 ' + bias.toFixed(2) + '  ·  所有贡献之和经 sigmoid 映射为当前概率');
  }

  function render() {
    var windowWidth = Number(controls.window.value) / 100;
    var margin = Number(controls.margin.value) / 100;
    var history = Number(controls.history.value) / 100;
    var threshold = Number(controls.threshold.value) / 100;
    var x = features(windowWidth, margin, history);
    var p = predict(model.model, x);
    var ev = evaluate(model.test, model.model, threshold);
    var level = p >= threshold ? '高风险 · 复核' : p >= threshold * 0.55 ? '关注' : '较低';
    var tone = p >= threshold ? 'high' : p >= threshold * 0.55 ? 'mid' : '';

    out.window.textContent = windowWidth.toFixed(2) + ' g/cm³';
    out.margin.textContent = margin.toFixed(2) + ' g/cm³';
    out.history.textContent = Number(controls.history.value) + '%';
    out.threshold.textContent = Number(controls.threshold.value) + '%';
    out.probability.textContent = Math.round(p * 100) + '%';
    out.level.textContent = level;
    out.level.className = 'risk-pill' + (tone ? ' ' + tone : '');
    out.bar.style.width = (p * 100) + '%';
    out.bar.className = tone;
    out.thresholdMark.style.left = (threshold * 100) + '%';
    out.recommendation.textContent = p >= threshold
      ? '当前合成井次达到预警阈值，建议复核压力窗口、井径资料和邻井施工记录。'
      : '当前合成井次低于预警阈值；仍需结合资料质量和工程判断。';
    out.brier.textContent = ev.brier.toFixed(3);
    out.recall.textContent = Math.round(ev.recall * 100) + '%';
    out.size.textContent = String(model.test.length);
    renderPressure(windowWidth, margin);
    renderCurve(windowWidth, margin, history);
    renderContributions(x);
    var contributions=x.map(function(v,i){return v*model.model.weights[i];});var baseBrier=model.test.reduce(function(s,r){return s+Math.pow(model.prior-r.y,2);},0)/model.test.length;
 window.AIProof.update({bars:[{label:'学习到的截距',value:model.model.bias}].concat(contributions.map(function(v,i){return {label:['窗口偏窄','ECD 余量小','历史漏失频率'][i],value:v};})),detail:'z = '+model.model.bias.toFixed(3)+' + '+contributions.map(function(v){return v.toFixed(3);}).join(' + ')+'；sigmoid(z) = '+p.toFixed(3)+'。告警阈值决定复核，不改变模型分数。',note:'权重由训练样本学习，柱条为当前模型的加法计算；它不等于因果贡献。',comparison:[{label:'固定训练频率',value:baseBrier},{label:'逻辑回归',value:ev.brier}],digits:3,comparisonUnit:'160 个留出样本的 Brier 分数，越低越好',comparisonNote:'基线始终预测训练集正例频率；模型和基线使用同一留出标签，不用当前滑块标签充当验证。'});
  }

  model = fitModel();
  [controls.window, controls.margin, controls.history, controls.threshold].forEach(function (input) {
    input.addEventListener('input', render);
  });
  render();
}());

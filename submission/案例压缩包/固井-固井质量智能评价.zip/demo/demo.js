/* final-lab-interactions:start */
(function(){
  'use strict';
  var configs={
    c1:{metrics:[['selected-class','候选类别'],['selected-confidence','相似度置信分'],['review-share','复核比例']],presets:[['良好响应','低振幅与较弱套管波特征',{depth:24,confidence:72}],['过渡区间','检查靠近分类边界的位置',{depth:72,confidence:92}],['较差响应','比较较强套管波特征',{depth:112,confidence:72}]]},
    c2:{metrics:[['current-efficiency','当前预测效率'],['best-efficiency','候选最高效率'],['frac-margin','破裂压力余量']],presets:[['保守方案','较低排量与适中密度',{density:1400,rate:8,centralization:70}],['高排量试探','检查效率改善是否触及压力约束',{density:1640,rate:20,centralization:70}],['改善居中度','固定密度排量，只改变几何条件',{density:1500,rate:13,centralization:95}]]},
    c3:{metrics:[['risk-probability','模型风险分数'],['risk-level','当前风险提示'],['recall-score','留出样本召回率']],presets:[['宽窗口','余量充足，邻井历史频率低',{'window-width':75,'ecd-margin':24,'history-rate':0,'decision-threshold':45}],['窄窗口','多因素叠加，观察贡献变化',{'window-width':25,'ecd-margin':3,'history-rate':45,'decision-threshold':45}],['提高阈值','固定井况，区分分数与决策',{'window-width':42,'ecd-margin':10,'history-rate':18,'decision-threshold':70}]]},
    c4:{metrics:[['min-after','方案最小居中度'],['coverage-after','目标覆盖率'],['used-count','扶正器数量']],presets:[['无扶正器','建立原始几何对照',{eccentricity:55,target:65,'max-centralizers':0,depth:120}],['布置五个','在数量约束下搜索薄弱段',{eccentricity:55,target:65,'max-centralizers':5,depth:120}],['增加上限','观察新增位置是否仍有收益',{eccentricity:55,target:65,'max-centralizers':8,depth:120}]]},
    d2:{metrics:[['anomaly-score','异常分数'],['persistence','超限持续窗'],['top-channel','贡献最大通道']],presets:[['正常留出窗','正常工况下也应检查误报',{scenario:'normal','time-index':100,threshold:62}],['井漏前兆','让多个通道共同参与判断',{scenario:'loss','time-index':100,threshold:62}],['降低阈值','相同早期时刻，调整决策灵敏度',{scenario:'loss','time-index':80,threshold:35}]]}
  };
  var scene=document.querySelector('main').dataset.scene,config=configs[scene];if(!config)return;
  var root=document.getElementById('lab-interactions');if(!root)return;
  root.innerHTML='<div class="guided-top"><div><span>EXPERIMENT / 自己动手验证</span><h2>先选工况，再保存一组对照。</h2></div><span class="guided-index">'+(scene==='d2'?'拓展实验':'固井实验')+'</span></div><div class="guided-presets">'+config.presets.map(function(p,i){return '<button type="button" data-lab-preset="'+i+'" aria-pressed="false"><b>0'+(i+1)+'</b><span>'+p[0]+'<small>'+p[1]+'</small></span><i>↗</i></button>';}).join('')+'</div><div class="comparison-tools"><p id="guided-instruction">点击一种典型工况；保存为 A 后，调整下方参数查看 A / B 对比。</p><button type="button" id="save-lab-baseline">保存当前为方案 A</button><button type="button" id="clear-lab-baseline" hidden>清除对照</button></div><div id="lab-comparison" hidden aria-live="polite"></div>';
  var saved=null;
  function measure(){return config.metrics.map(function(m){var node=document.getElementById(m[0]);return {label:m[1],text:node?node.textContent.trim():'—'};});}
  function safe(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function conditionText(inputs){var names={confidence:'最低置信 %',depth:'测深 m',density:'密度 kg/m³',rate:'排量 L/s',centralization:'居中度 %','window-width':'窗口宽度 ×0.01 g/cm³','ecd-margin':'ECD 余量 ×0.01 g/cm³','history-rate':'历史频率 %','decision-threshold':'预警阈值 %',eccentricity:'偏心 %',target:'目标 %','max-centralizers':'数量上限',threshold:'阈值 %','time-index':'时间窗索引'};return inputs.map(function(x){return (names[x.id]||x.id)+' '+x.value;}).join(' · ');}
  function compare(){if(!saved)return;var now=measure(),out=document.getElementById('lab-comparison');out.hidden=false;out.innerHTML='<div class="compare-intro"><span>方案 A · 保存时的输入</span><span>方案 B · 当前输入</span></div>'+now.map(function(m,i){var a=saved.metrics[i].text,b=m.text,an=parseFloat(a),bn=parseFloat(b),valid=Number.isFinite(an)&&Number.isFinite(bn),max=valid?Math.max(Math.abs(an),Math.abs(bn),1):1;return '<div class="compare-row"><b>'+m.label+'</b><div><span>'+safe(a)+'</span>'+(valid?'<i class="compare-bar a" style="width:'+Math.max(1,Math.abs(an)/max*100)+'%"></i>':'')+'</div><div><span>'+safe(b)+'</span>'+(valid?'<i class="compare-bar b" style="width:'+Math.max(1,Math.abs(bn)/max*100)+'%"></i>':'')+'</div><small>'+(a===b?'相同':valid?'变化 '+(bn-an>=0?'+':'')+(bn-an).toFixed(2):'结果变化')+'</small></div>';}).join('')+'<div class="compare-conditions"><p><b>A 条件：</b>'+safe(conditionText(saved.inputs))+'</p><p><b>B 条件：</b>'+safe(conditionText(Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})))+'</p></div><p class="comparison-boundary">对比当前演示的实际显示结果；数值变化不自动代表工程更优。概率 / 分数、余量、覆盖率需结合方法边界分别解释。</p>';}
  root.querySelectorAll('[data-lab-preset]').forEach(function(button){button.addEventListener('click',function(){var preset=config.presets[Number(button.dataset.labPreset)];if(scene==='d2'){var pause=document.getElementById('pause');if(pause)pause.click();if(preset[2].scenario)document.querySelector('[data-scenario="'+preset[2].scenario+'"]').click();}Object.keys(preset[2]).forEach(function(id){if(id==='scenario')return;var input=document.getElementById(id);if(input){input.value=preset[2][id];input.dispatchEvent(new Event('input',{bubbles:true}));}});root.querySelectorAll('[data-lab-preset]').forEach(function(b){b.classList.toggle('on',b===button);b.setAttribute('aria-pressed',String(b===button));});document.getElementById('guided-instruction').textContent='正在观察：'+preset[0]+'。'+preset[1]+'。下方图表、指标和模型依据已重新计算。';compare();});});
  root.querySelector('#save-lab-baseline').addEventListener('click',function(){saved={metrics:measure(),inputs:Array.from(document.querySelectorAll('input[type=range]')).map(function(i){return {id:i.id,value:i.value};})};this.textContent='更新方案 A';document.getElementById('clear-lab-baseline').hidden=false;document.getElementById('guided-instruction').textContent='已保存方案 A。现在选择另一工况或调整参数，观察 B 的变化。';compare();});
  root.querySelector('#clear-lab-baseline').addEventListener('click',function(){saved=null;document.getElementById('lab-comparison').hidden=true;this.hidden=true;document.getElementById('save-lab-baseline').textContent='保存当前为方案 A';});
  document.addEventListener('input',function(e){if(e.target.matches('input[type=range]'))requestAnimationFrame(compare);});
  window.LabCompare={refresh:compare};
})();
/* final-lab-interactions:end */


/* ai-proof:start */
(function(){
  'use strict';var NS='http://www.w3.org/2000/svg',current=null,mode='calculation';
  function el(tag,attrs,parent,text){var n=document.createElementNS(NS,tag);Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;parent.appendChild(n);return n;}
  function draw(){if(!current)return;var c=current,s=document.getElementById('ai-proof-chart');if(!s)return;s.textContent='';var narrow=innerWidth<620,W=narrow?360:Math.max(460,Math.min(760,s.getBoundingClientRect().width||760));s.setAttribute('viewBox','0 0 '+W+' 252');
    var left=narrow?112:176,right=W-72,top=40,height=160;
    document.getElementById('ai-proof-live').textContent=c.detail;
    document.getElementById('ai-proof-caption').textContent=mode==='comparison'?c.comparisonNote:c.note;
    if(mode==='calculation'&&c.points){
      left=44;right=W-35;var colors=['#2e8064','#b08a3e','#b66647'];
      [0,.5,1].forEach(function(v){var x=left+v*(right-left),y=top+(1-v)*height;el('path',{d:'M'+x+' '+top+'V'+(top+height)+'M'+left+' '+y+'H'+right,stroke:'#e1e8dd',fill:'none'},s);el('text',{x:x,y:top+height+18,'text-anchor':'middle',fill:'#7d8e7c','font-size':10},s,v);});
      c.points.forEach(function(p){el('circle',{cx:left+p.x*(right-left),cy:top+(1-p.y)*height,r:2.5,fill:colors[p.cls],opacity:.65},s);});
      c.centers.forEach(function(p,i){var x=left+p[0]*(right-left),y=top+(1-p[1])*height;el('line',{x1:left+c.selected[0]*(right-left),y1:top+(1-c.selected[1])*height,x2:x,y2:y,stroke:colors[i],'stroke-dasharray':'4 4'},s);el('path',{d:'M'+(x-5)+' '+y+'h10M'+x+' '+(y-5)+'v10',stroke:colors[i],'stroke-width':3},s);});
      el('circle',{cx:left+c.selected[0]*(right-left),cy:top+(1-c.selected[1])*height,r:6,fill:'#183f2d',stroke:'#fff','stroke-width':2},s);el('text',{x:W/2,y:245,'text-anchor':'middle',fill:'#607b63','font-size':10},s,'横轴：CBL 归一化特征 · 纵轴：VDL 特征 · 十字：训练中心');
    }else{
      var bars=mode==='comparison'?c.comparison:c.bars;var max=c.fixedMax||Math.max.apply(null,bars.map(function(b){return Math.abs(b.value);}).concat([.001]));var rowH=Math.min(37,180/bars.length);
      bars.forEach(function(b,i){var y=top+i*rowH,bar=Math.min(1,Math.abs(b.value)/max)*(right-left);el('text',{x:left-10,y:y+11,'text-anchor':'end',fill:'#62775f','font-size':narrow?10:11},s,b.label);el('rect',{x:left,y:y,width:right-left,height:15,rx:2,fill:'#edf1e7'},s);el('rect',{x:left,y:y,width:Math.max(.5,bar),height:15,rx:2,fill:b.value<0?'#b37450':i===0&&mode==='comparison'?'#98a78c':'#3c8060'},s);el('text',{x:right+8,y:y+12,fill:'#3f6749','font-size':11},s,(b.value<0?'−':'')+Math.abs(b.value).toFixed(c.digits==null?2:c.digits)+(c.unit||''));});
      el('text',{x:left,y:235,fill:'#8a987f','font-size':10},s,mode==='comparison'?'同一组对照条件 · '+(c.comparisonUnit||''):c.axis||'柱长表示该项数值大小；符号见右侧');
    }
  }
  window.AIProof={update:function(c){current=c;draw();if(window.LabCompare)requestAnimationFrame(window.LabCompare.refresh);}};
  document.addEventListener('click',function(e){var b=e.target.closest('[data-proof-mode]');if(!b)return;mode=b.dataset.proofMode;document.querySelectorAll('[data-proof-mode]').forEach(function(n){var on=n===b;n.classList.toggle('on',on);n.setAttribute('aria-pressed',String(on));});draw();});
  window.addEventListener('resize',draw);
})();
/* ai-proof:end */

(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var STEP = 4;
  var END_DEPTH = 240;
  var CLASS_NAMES = ['胶结较好', '可疑 / 过渡', '胶结较差'];
  var CLASS_COLORS = ['#2d7968', '#a6813b', '#bd6841'];
  var CLASS_BG = ['#e5f0ec', '#f7f0de', '#f6eae3'];
  var controls = { confidence: document.getElementById('confidence'), depth: document.getElementById('depth') };
  var out = {
    confidence: document.getElementById('confidence-output'), depth: document.getElementById('depth-output'),
    accuracy: document.getElementById('accuracy'), review: document.getElementById('review-share'),
    selectedClass: document.getElementById('selected-class'), selectedConfidence: document.getElementById('selected-confidence'),
    reference: document.getElementById('reference-class'), detail: document.getElementById('detail-copy')
  };
  var chart = document.getElementById('log-chart');
  var random = makeRandom(20261028);
  var model = trainClassifier();
  var samples = makeWell();
  var state = { threshold: 72, depth: 120 };

  function svg(tag, attrs, parent, text) {
    var node = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    if (text != null) node.textContent = text;
    if (parent) parent.appendChild(node);
    return node;
  }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function makeRandom(seed) {
    var n = seed >>> 0;
    return function () { n = (1664525 * n + 1013904223) >>> 0; return n / 4294967296; };
  }
  function classForDepth(depth) {
    if (depth < 52) return 0;
    if (depth < 88) return 1;
    if (depth < 132) return 2;
    if (depth < 164) return 1;
    return 0;
  }
  function meansForClass(cls) {
    return [[0.24, 0.22], [0.53, 0.55], [0.83, 0.82]][cls];
  }
  function trainClassifier() {
    var means = [[0, 0], [0, 0], [0, 0]];
    var counts = [0, 0, 0];
    var test = [];
    var training = [];
    for (var cls = 0; cls < 3; cls++) {
      for (var i = 0; i < 100; i++) {
        var mean = meansForClass(cls);
        var point = [clamp(mean[0] + (random() - 0.5) * 0.24, 0, 1), clamp(mean[1] + (random() - 0.5) * 0.24, 0, 1)];
        if (i < 72) {
          training.push({x:point[0],y:point[1],cls:cls});
          means[cls][0] += point[0];
          means[cls][1] += point[1];
          counts[cls]++;
        } else {
          test.push({ x: point, y: cls });
        }
      }
    }
    means = means.map(function (m, index) { return [m[0] / counts[index], m[1] / counts[index]]; });
    var correct = test.reduce(function (sum, row) { return sum + (classify(row.x, means).cls === row.y ? 1 : 0); }, 0);
    return { means: means, accuracy: correct / test.length, testCount: test.length, training:training, test:test };
  }
  function classify(x, means) {
    var best = 0, bestD = Infinity;
    means.forEach(function (m, cls) {
      var d = Math.sqrt(Math.pow(x[0] - m[0], 2) + Math.pow(x[1] - m[1], 2));
      if (d < bestD) { bestD = d; best = cls; }
    });
    return { cls: best, confidence: clamp(1 - bestD / 0.34, 0, 1), distance: bestD };
  }
  function makeWell() {
    var rows = [];
    for (var depth = 0; depth <= END_DEPTH; depth += STEP) {
      var cls = classForDepth(depth);
      var mean = meansForClass(cls);
      var wave = Math.sin(depth / 17) * 0.035 + Math.cos(depth / 31) * 0.025;
      var features = [clamp(mean[0] + wave + (random() - 0.5) * 0.10, 0.05, 0.97), clamp(mean[1] + Math.sin(depth / 13) * 0.045 + (random() - 0.5) * 0.12, 0.05, 0.97)];
      rows.push({ depth: depth, reference: cls, features: features, prediction: classify(features, model.means) });
    }
    return rows;
  }
  function rowAtDepth(depth) { return samples[clamp(Math.round(depth / STEP), 0, samples.length - 1)]; }

  function renderChart() {
    chart.textContent = '';
    var narrow = window.innerWidth <= 620;
    var viewWidth = narrow ? 820 : 820;
    chart.setAttribute('viewBox', '0 0 ' + viewWidth + ' 438');
    var top = 52, height = 326;
    var y = function (depth) { return top + depth / END_DEPTH * height; };
    var cblX = 140, cblW = 130, vdlX = 330, vdlW = 272, classX = 650, classW = 125;
    var grid = '#e6ece8', muted = '#788780';

    svg('text', { x: 32, y: 27, fill: muted, 'font-size': 9, 'font-family': 'sans-serif' }, chart, '深度 m');
    svg('text', { x: cblX + cblW / 2, y: 27, 'text-anchor': 'middle', fill: '#566760', 'font-size': 10, 'font-family': 'sans-serif' }, chart, 'CBL 振幅 mV');
    svg('text', { x: vdlX + vdlW / 2, y: 27, 'text-anchor': 'middle', fill: '#566760', 'font-size': 10, 'font-family': 'sans-serif' }, chart, 'VDL 波形强度 / 传播时间');
    svg('text', { x: classX + classW / 2, y: 27, 'text-anchor': 'middle', fill: '#566760', 'font-size': 10, 'font-family': 'sans-serif' }, chart, '模型分段');

    [0, 20, 40, 60, 80, 100].forEach(function (tick) {
      var xx = cblX + tick / 100 * cblW;
      svg('line', { x1: xx, x2: xx, y1: top, y2: top + height, stroke: grid, 'stroke-width': 1 }, chart);
      svg('text', { x: xx, y: top - 8, 'text-anchor': 'middle', fill: muted, 'font-size': 8, 'font-family': 'sans-serif' }, chart, String(tick));
    });
    [0, 60, 120, 180, 240].forEach(function (depth) {
      var yy = y(depth);
      svg('line', { x1: 70, x2: classX + classW, y1: yy, y2: yy, stroke: grid, 'stroke-width': 1 }, chart);
      svg('text', { x: 60, y: yy + 3, 'text-anchor': 'end', fill: muted, 'font-size': 9, 'font-family': 'sans-serif' }, chart, String(depth));
    });
    svg('rect', { x: cblX, y: top, width: cblW, height: height, fill: 'none', stroke: '#cdd8d2' }, chart);
    svg('rect', { x: vdlX, y: top, width: vdlW, height: height, fill: '#f2f4f3', stroke: '#cdd8d2' }, chart);
    svg('rect', { x: classX, y: top, width: classW, height: height, fill: '#fff', stroke: '#cdd8d2' }, chart);

    var path = [];
    samples.forEach(function (row, index) {
      var yy = y(row.depth);
      var amp = row.features[0] * 100;
      var xx = cblX + amp / 100 * cblW;
      path.push((index ? 'L' : 'M') + xx.toFixed(1) + ' ' + yy.toFixed(1));

      var tileCount = 34;
      var tileW = vdlW / tileCount;
      var rowH = height / (samples.length - 1);
      for (var col = 0; col < tileCount; col++) {
        var t = col / (tileCount - 1);
        var casingArrival = Math.exp(-Math.pow((t - (0.2 + row.features[1] * 0.25)) / 0.09, 2));
        var formationArrival = Math.exp(-Math.pow((t - (0.72 + 0.04 * Math.sin(row.depth / 24))) / 0.13, 2));
        var intensity = clamp(Math.round(225 - 125 * casingArrival * (0.35 + row.features[1]) - 80 * formationArrival * (1 - row.features[1] * 0.35)), 25, 238);
        var color = 'rgb(' + intensity + ',' + intensity + ',' + intensity + ')';
        svg('rect', { x: (vdlX + col * tileW).toFixed(2), y: (yy - rowH / 2).toFixed(2), width: (tileW + 0.2).toFixed(2), height: (rowH + 0.2).toFixed(2), fill: color }, chart);
      }

      var cellH = rowH + 0.3;
      svg('rect', { x: classX + 2, y: (yy - cellH / 2).toFixed(2), width: classW - 4, height: cellH.toFixed(2), fill: CLASS_BG[row.prediction.cls] }, chart);
      if (row.prediction.confidence * 100 < state.threshold) {
        svg('line', { x1: classX + 3, x2: classX + classW - 3, y1: yy, y2: yy, stroke: CLASS_COLORS[2], 'stroke-width': 1.3, 'stroke-dasharray': '2 3' }, chart);
      }
    });
    svg('path', { d: path.join(' '), fill: 'none', stroke: '#263a34', 'stroke-width': 1.8, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, chart);

    var current = rowAtDepth(state.depth);
    var cursorY = y(current.depth);
    svg('line', { x1: 70, x2: classX + classW, y1: cursorY, y2: cursorY, stroke: '#1d302c', 'stroke-width': 1.4, 'stroke-dasharray': '4 3' }, chart);
    svg('circle', { cx: cblX + current.features[0] * cblW, cy: cursorY, r: 4, fill: '#fff', stroke: '#263a34', 'stroke-width': 2 }, chart);
    svg('circle', { cx: vdlX + vdlW * (0.2 + current.features[1] * 0.25), cy: cursorY, r: 3.5, fill: CLASS_COLORS[current.prediction.cls], stroke: '#fff', 'stroke-width': 1.3 }, chart);
  }

  function renderDetail() {
    var row = rowAtDepth(state.depth);
    var cls = row.prediction.cls;
    var low = row.prediction.confidence * 100 < state.threshold;
    out.depth.textContent = row.depth + ' m';
    out.selectedClass.textContent = CLASS_NAMES[cls];
    out.selectedClass.style.color = CLASS_COLORS[cls];
    out.selectedConfidence.textContent = Math.round(row.prediction.confidence * 100) + '% 相似度置信分' + (low ? ' · 需人工复核' : '');
    out.selectedConfidence.style.color = low ? '#9d4e2d' : '#697a74';
    out.reference.textContent = CLASS_NAMES[row.reference];
    out.reference.style.color = CLASS_COLORS[row.reference];
    var amplitude = Math.round(row.features[0] * 100);
    var wave = Math.round(row.features[1] * 100);
    var signal = cls === 0 ? '相对较低的套管波特征' : cls === 1 ? '介于两类之间的声学特征' : '相对较强且连续的套管波特征';
    out.detail.textContent = row.depth + ' m：CBL 合成相对振幅 ' + amplitude + ' mV，VDL 合成连续性特征 ' + wave + '%；最近质心模型识别为“' + CLASS_NAMES[cls] + '”（' + signal + '）。参考合成标签为“' + CLASS_NAMES[row.reference] + '”。' + (low ? '当前置信分低于 ' + state.threshold + '%，进入人工复核队列。' : '当前置信分达到设定要求，但仍应结合井径和施工资料解释。');
  }

  function render() {
    state.threshold = Number(controls.confidence.value);
    state.depth = Number(controls.depth.value);
    var lowCount = samples.filter(function (row) { return row.prediction.confidence * 100 < state.threshold; }).length;
    out.confidence.textContent = state.threshold + '%';
    out.accuracy.textContent = Math.round(model.accuracy * 100) + '%';
    out.review.textContent = Math.round(lowCount / samples.length * 100) + '%';
    renderDetail();
    renderChart();
    var proofRow=rowAtDepth(state.depth);var simpleAccuracy=model.test.reduce(function(s,r){var cls=r.x[0]<.38?0:r.x[0]<.68?1:2;return s+(cls===r.y?1:0);},0)/model.test.length;
 window.AIProof.update({points:model.training,centers:model.means,selected:proofRow.features,detail:proofRow.depth+' m：到三类中心的距离为 '+model.means.map(function(m){return Math.hypot(proofRow.features[0]-m[0],proofRow.features[1]-m[1]).toFixed(3);}).join(' / ')+'。模型选择最近的中心；置信要求只改变复核标志，不重新训练。',note:'点来自实际合成训练集；当前点和三条距离随测深选择更新。',comparison:[{label:'单一声幅阈值',value:simpleAccuracy*100},{label:'双特征分类',value:model.accuracy*100}],unit:'%',digits:1,comparisonUnit:'准确率，越高越好',comparisonNote:'同 84 个留出样本。本合成数据较易分开，两种方法可能同样准确，不能据此证明模型优势。'});
  }

  controls.confidence.addEventListener('input', render);
  controls.depth.addEventListener('input', render);
  chart.addEventListener('pointerdown', function (event) {
    var rect = chart.getBoundingClientRect();
    var viewY = (event.clientY - rect.top) * 438 / rect.height;
    var top = 52, height = 326;
    if (viewY < top || viewY > top + height) return;
    state.depth = clamp(Math.round(((viewY - top) / height * END_DEPTH) / STEP) * STEP, 0, END_DEPTH);
    controls.depth.value = state.depth;
    render();
  });
  render();
}());
